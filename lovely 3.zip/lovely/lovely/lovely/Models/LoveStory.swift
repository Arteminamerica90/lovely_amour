//
//  LoveStory.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import Foundation

struct LoveStory: Identifiable, Codable {
    let id: UUID
    var title: String
    var content: String
    var date: Date
    var isFavorite: Bool
    var language: String
    
    init(id: UUID = UUID(), title: String, content: String, date: Date = Date(), isFavorite: Bool = false, language: String = "ru") {
        self.id = id
        self.title = title
        self.content = content
        self.date = date
        self.isFavorite = isFavorite
        self.language = language
    }
}

class LoveStoriesData: ObservableObject {
    @Published var stories: [LoveStory] = []
    private let storiesKey = "LoveStories"
    
    init() {
        loadStories()
    }
    
    func loadStories() {
        if let data = UserDefaults.standard.data(forKey: storiesKey),
           let decoded = try? JSONDecoder().decode([LoveStory].self, from: data) {
            stories = decoded
        }
        
        var didAppendSeed = false
        let seedStories = Self.defaultStories()
        
        for seed in seedStories {
            let exists = stories.contains {
                $0.title == seed.title && $0.language == seed.language
            }
            if !exists {
                stories.append(seed)
                didAppendSeed = true
            }
        }
        
        if stories.isEmpty {
            stories = seedStories
            didAppendSeed = true
        }
        
        if didAppendSeed {
            saveStories()
        }
    }
    
    func saveStories() {
        if let encoded = try? JSONEncoder().encode(stories) {
            UserDefaults.standard.set(encoded, forKey: storiesKey)
        }
    }
    
    func addStory(_ story: LoveStory) {
        stories.append(story)
        saveStories()
    }
    
    func updateStory(_ story: LoveStory) {
        if let index = stories.firstIndex(where: { $0.id == story.id }) {
            stories[index] = story
            saveStories()
        }
    }
    
    func deleteStory(_ story: LoveStory) {
        stories.removeAll { $0.id == story.id }
        saveStories()
    }
    
    func toggleFavorite(_ story: LoveStory) {
        if let index = stories.firstIndex(where: { $0.id == story.id }) {
            stories[index].isFavorite.toggle()
            saveStories()
        }
    }
    
    func getStories(for language: String) -> [LoveStory] {
        return stories.filter { $0.language == language }
    }
    
    private static func defaultStories() -> [LoveStory] {
        let now = Date()
        let calendar = Calendar.current
        
        func date(daysAgo: Int) -> Date {
            calendar.date(byAdding: .day, value: -daysAgo, to: now) ?? now
        }
        
        return [
            LoveStory(
                title: "Поезд метро до параллельной реальности",
                content: "Мы с тобой случайно свернули не на тот эскалатор и оказались в поезде без окон. Вместо объявлений станций — наши любимые песни. На стенах появились фотографии из будущего, где мы смеемся, стареем и снова смеемся. Поезд высадил нас там же, но на платформе лежала записка: \"Не упустите следующий шанс\". С тех пор мы выходим из метро на одну станцию раньше, чтобы прогуляться и не упустить чудо.",
                date: date(daysAgo: 3),
                language: "ru"
            ),
            LoveStory(
                title: "Фотолаборатория времени",
                content: "В старой подворотне мы нашли фотолабораторию, где принимали только пленку, снятую на эмоциях. Мы оставили кассету с нашими смехами и руганью. Через сутки получили снимки из будущего: мы стоим в квартире у моря, спорим, кто забыл выключить чайник. Чайника у нас пока нет, но каждый вечер мы оставляем пленку, чтобы не забыть, как звучит наш день.",
                date: date(daysAgo: 8),
                language: "ru"
            ),
            LoveStory(
                title: "Пароход с библиотекой снов",
                content: "На прогулочном пароходе вместо музыки устроили читальный зал. Пассажиры вслух рассказывали свои вчерашние сны, пока город проплывал мимо. Ты записывал каждую деталь, а потом заметил, что вода отражает не дома, а то, что мы произносили. С тех пор мы храним «карту снов» и дополняем её по воскресеньям.",
                date: date(daysAgo: 14),
                language: "ru"
            ),
            LoveStory(
                title: "Голосовой маяк на крыше",
                content: "Мы поднялись на крышу высотки, где кто-то построил маяк из фонариков и радиоколонок. Любой мог оставить голосовое сообщение, и оно превращалось в световой сигнал. Мы записали три слова, которые понимаем только мы, и луч прорисовал их в ночном небе. Теперь, когда идёт дождь, мы ищем наш сигнал среди отражений в лужах.",
                date: date(daysAgo: 21),
                language: "ru"
            ),
            LoveStory(
                title: "Секретный трамвай на рассвете",
                content: "Московский трамвай, который ходит только на рассвете, довёз нас до пустого парка аттракционов. Колесо обозрения включило подсветку и заиграло мелодию нашего первого будильника. Мы катались, пока город не проснулся, и украсили вагон бумажными журавлями, чтобы он не забывал о нас.",
                date: date(daysAgo: 27),
                language: "ru"
            ),
            LoveStory(
                title: "Aurora Over Reykjavik",
                content: "We were in Reykjavik for twenty-four hours, chasing auroras that refused to show. On a whim we hiked to a geothermal plant at midnight, the only light coming from turbines humming like distant whales. Suddenly the sky folded itself into ribbons of green and violet, spelling out Morse code that matched the rhythm of your heartbeat on my chest. When the lights faded, the turbines switched off. The guide swears that plant never stops.",
                date: date(daysAgo: 5),
                language: "en"
            ),
            LoveStory(
                title: "The Chapel of Misplaced Echoes",
                content: "In Prague we stumbled into a tiny chapel rumored to collect echoes that never found their way back. Whispering our names into the altar made the walls respond with fragments of strangers’ vows. When we stepped outside, street musicians were playing a melody that matched those syllables. We recorded it and keep it as our 'emergency promise' track.",
                date: date(daysAgo: 10),
                language: "en"
            ),
            LoveStory(
                title: "The Overnight Museum Heist (of Smiles)",
                content: "Volunteering at an art museum, we discovered a storage room filled with anonymous portraits. After hours we projected our own selfies onto the blank canvases, swapping expressions until the motion sensors started clapping instead of alarming. Security let us finish, saying the portraits hadn’t smiled in decades. Now we sneak postcards with new expressions into the gift shop.",
                date: date(daysAgo: 18),
                language: "en"
            ),
            LoveStory(
                title: "Stargazing on the Abandoned Runway",
                content: "We drove to the abandoned runway outside town armed with glow-in-the-dark paint. While planes slept, we connected constellations directly on the asphalt, tracing our private zodiac. A meteor lit the runway numbers. The next week commercial flights resumed, but pilots reported seeing a heart-shaped constellation on landing.",
                date: date(daysAgo: 24),
                language: "en"
            ),
            LoveStory(
                title: "La bibliothèque qui n’existait plus",
                content: "Nous avons poussé une porte en bois dans une ruelle du Marais. À l’intérieur, une bibliothèque remplie de journaux intimes jamais écrits. On nous a demandé de déposer une page du futur. Nous avons décrit notre dîner d’anniversaire dans cinquante ans. Le lendemain, la ruelle était murée, mais depuis la confiture de figues ne manque jamais dans notre cuisine.",
                date: date(daysAgo: 7),
                language: "fr"
            ),
            LoveStory(
                title: "Le carrousel des rendez-vous manqués",
                content: "À Lyon, un carrousel ouvrait une seule nuit par mois pour les rendez-vous manqués. Chaque cheval portait un prénom. Nous avons monté celui qui portait nos premiers coups de cœur. Le manège nous a raconté ce qu’aurait pu être cette histoire. On rit encore en repensant à la voix du cheval qui nous suppliait de ne plus être timides.",
                date: date(daysAgo: 13),
                language: "fr"
            ),
            LoveStory(
                title: "La serre aux horloges inversées",
                content: "Dans une serre abandonnée, toutes les horloges tournaient à l'envers, faisant fleurir les plantes la nuit. Nous avons enterré notre liste de regrets sous un figuier, et au matin, un fruit parfaitement mûr nous attendait. Depuis, on coupe une figue en deux pour vérifier l'heure qu'il est vraiment.",
                date: date(daysAgo: 20),
                language: "fr"
            ),
            LoveStory(
                title: "Le théâtre des parapluies perdus",
                content: "À Nantes, les parapluies perdus deviennent marionnettes. On a improvisé une pièce où chaque parapluie représentait une version de nous qui n'avait jamais osé s'avouer ses sentiments. À la fin, les mouettes nous ont offert un bouquet de baleines de parapluie. On les a plantées sur le balcon comme rappel de dire «je t'aime» avant la pluie.",
                date: date(daysAgo: 29),
                language: "fr"
            ),
            LoveStory(
                title: "Correo desde la Estación Horizonte",
                content: "Un sobre sin remitente llegó con timbres de planetas desconocidos. Dentro había una postal escrita con nuestra letra, firmada en una estación espacial llamada Horizonte. Decía que habíamos decidido no volver porque el amanecer sobre Saturno era adictivo. Esa noche subimos a la azotea y juramos seguir enviándonos postales del futuro.",
                date: date(daysAgo: 6),
                language: "es"
            ),
            LoveStory(
                title: "La estación que olía a mandarinas",
                content: "En Sevilla, una estación de tren abandonada olía intensamente a mandarinas. Seguimos el aroma hasta una máquina expendedora que solo aceptaba abrazos. Le dimos tres y nos escupió billetes con versos escritos. Desde entonces guardamos uno en la cartera y cada diciembre compramos mandarinas para recordar el camino.",
                date: date(daysAgo: 15),
                language: "es"
            ),
            LoveStory(
                title: "El club de las cartas sin sello",
                content: "Una vez al mes, en Ciudad de México, se reúne un club para escribir cartas sin remitente. Dejamos la nuestra contando el día que casi perdimos un vuelo por bailar en la fila de seguridad. Tres meses después, recibimos una carta idéntica firmada por «Nuestros yo del 2045».",
                date: date(daysAgo: 23),
                language: "es"
            ),
            LoveStory(
                title: "La nevada en la playa prohibida",
                content: "En Valparaíso, la playa cerrada por marejadas recibió una nevada imposible en pleno verano. Construimos un castillo de nieve con conchas y lo bautizamos «Nuestro país inverosímil». Al amanecer la nieve desapareció, pero las conchas formaban un mapa que aún seguimos explorando.",
                date: date(daysAgo: 34),
                language: "es"
            ),
            LoveStory(
                title: "La escalera que cantaba tangos",
                content: "En Buenos Aires subimos una escalera de hierro que cantaba tangos al ritmo de nuestros pasos. Cada peldaño activaba una frase distinta. Llegamos arriba bailando, justo cuando una vecina nos lanzó dos vasos de limonada: «Para la pareja que hizo llorar a Gardel».",
                date: date(daysAgo: 41),
                language: "es"
            ),
            LoveStory(
                title: "O concerto das baleias urbanas",
                content: "Na madrugada de neblina em Lisboa descemos ao cais para ouvir o silêncio. A Ponte 25 de Abril vibrou como violoncelo e do Tejo surgiram baleias transparentes cantando fado. Cada nota iluminava prédios adormecidos. Voltamos todo ano na mesma data para ver se elas lembram da gente.",
                date: date(daysAgo: 9),
                language: "pt"
            ),
            LoveStory(
                title: "O laboratório de saudades engarrafadas",
                content: "Em São Paulo existe um laboratório que engarrafa saudades em frascos coloridos. Guardamos o cheiro da primeira chuva que pegamos juntos. Às vezes abrimos o frasco e a sala fica com aquele aroma de asfalto molhado misturado com pipoca de panela.",
                date: date(daysAgo: 17),
                language: "pt"
            ),
            LoveStory(
                title: "O ônibus interestelar da linha 14-B",
                content: "No Porto pegamos um ônibus fantasma numerado 14-B. As janelas mostravam constelações em vez de ruas. Um casal de idosos disse que o ônibus aparece para quem precisa de uma conversa longa. Descemos com um mapa celeste desenhado à mão e a certeza de viajar juntos até nas conversas difíceis.",
                date: date(daysAgo: 26),
                language: "pt"
            ),
            LoveStory(
                title: "A estação fantasma do Bonde Azul",
                content: "Em Lisboa pegamos o Bonde Azul, que faz uma parada extra quando alguém canta desafinado. Eu desafinei de propósito e chegamos a uma estação com azulejos que reproduziam mensagens em braile. Traduzimos cada um e encontramos uma receita de pastel de nata com pimenta-rosa. Virou nosso lanche secreto.",
                date: date(daysAgo: 33),
                language: "pt"
            ),
            LoveStory(
                title: "雾中的纸灯飞船",
                content: "那年深秋的上海雾大得看不见前方，我们把写着愿望的纸灯放进黄浦江。灯没有沉，也没有顺流而下，而是慢慢升起，变成一艘小小的飞船，绕着外滩盘旋，把雾气染成了桃粉色。第二天报纸说昨夜无人机表演失败，我们知道那是我们的飞船。",
                date: date(daysAgo: 11),
                language: "zh"
            ),
            LoveStory(
                title: "雨巷里的折纸剧场",
                content: "在成都的一条雨巷，我们遇到折纸剧团。每对观众都要折出自己的角色，我们折出两只纸鹤。演出时，纸鹤在屋檐间穿梭，把雨滴串成项链。临走前，它们落在我们肩上，留下两片描着墨迹的羽毛作书签。",
                date: date(daysAgo: 19),
                language: "zh"
            ),
            LoveStory(
                title: "雲海上的咖啡驿站",
                content: "冬天去张家界徒步，缆车在半山腰停了十分钟。雾海中出现一间小咖啡驿站，只有一位老人和手冲壶。老人说只招待迷路的情侣。我们喝完咖啡，缆车恢复运行，山下的咖啡馆菜单突然多了一款叫“迷路的云”的特调。",
                date: date(daysAgo: 28),
                language: "zh"
            ),
            LoveStory(
                title: "夜行列车的回声信",
                content: "北京到青岛的夜行列车空荡荡的，我们在餐车写给未来自己的信，塞进窗帘暗袋。清晨醒来，桌上多了两封回信，盖着“2038年”的邮戳，提醒我们别忘了在海边捡石头。到青岛那天，果然在沙滩上捡到一块刻着“2038”的石头。",
                date: date(daysAgo: 36),
                language: "zh"
            )
        ]
    }
}

