//
//  DateIdea.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import Foundation

enum DateIdeaCategory: String, CaseIterable, Identifiable, Codable {
    case classic = "Classic"
    case romantic = "Romantic"
    case adventurous = "Adventurous"
    case creative = "Creative"
    case cozy = "Cozy"
    case unusual = "Unusual"
    
    var id: String { rawValue }
    
    func localizedName(language: String) -> String {
        switch language {
        case "ru":
            switch self {
            case .classic: return "Классические"
            case .romantic: return "Романтические"
            case .adventurous: return "Приключенческие"
            case .creative: return "Креативные"
            case .cozy: return "Уютные"
            case .unusual: return "Необычные"
            }
        case "en":
            switch self {
            case .classic: return "Classic"
            case .romantic: return "Romantic"
            case .adventurous: return "Adventurous"
            case .creative: return "Creative"
            case .cozy: return "Cozy"
            case .unusual: return "Unusual"
            }
        case "fr":
            switch self {
            case .classic: return "Classique"
            case .romantic: return "Romantique"
            case .adventurous: return "Aventureux"
            case .creative: return "Créatif"
            case .cozy: return "Confortable"
            case .unusual: return "Inhabituel"
            }
        case "es":
            switch self {
            case .classic: return "Clásico"
            case .romantic: return "Romántico"
            case .adventurous: return "Aventurero"
            case .creative: return "Creativo"
            case .cozy: return "Acogedor"
            case .unusual: return "Inusual"
            }
        case "pt":
            switch self {
            case .classic: return "Clássico"
            case .romantic: return "Romântico"
            case .adventurous: return "Aventureiro"
            case .creative: return "Criativo"
            case .cozy: return "Aconchegante"
            case .unusual: return "Incomum"
            }
        case "zh":
            switch self {
            case .classic: return "经典"
            case .romantic: return "浪漫"
            case .adventurous: return "冒险"
            case .creative: return "创意"
            case .cozy: return "舒适"
            case .unusual: return "不寻常"
            }
        default:
            return rawValue
        }
    }
    
    var icon: String {
        switch self {
        case .classic: return "star.fill"
        case .romantic: return "heart.fill"
        case .adventurous: return "mountain.2.fill"
        case .creative: return "paintbrush.fill"
        case .cozy: return "house.fill"
        case .unusual: return "sparkles"
        }
    }
}

struct DateIdea: Identifiable, Codable {
    let id: UUID
    let title: String
    let description: String
    let titleRu: String?
    let descriptionRu: String?
    let titleFr: String?
    let descriptionFr: String?
    let titleEs: String?
    let descriptionEs: String?
    let titlePt: String?
    let descriptionPt: String?
    let titleZh: String?
    let descriptionZh: String?
    let category: DateIdeaCategory
    var isFavorite: Bool
    var userComment: String?
    var isUserCreated: Bool
    var authorName: String?
    var createdAt: Date
    
    init(id: UUID = UUID(), title: String, description: String, titleRu: String? = nil, descriptionRu: String? = nil, titleFr: String? = nil, descriptionFr: String? = nil, titleEs: String? = nil, descriptionEs: String? = nil, titlePt: String? = nil, descriptionPt: String? = nil, titleZh: String? = nil, descriptionZh: String? = nil, category: DateIdeaCategory, isFavorite: Bool = false, userComment: String? = nil, isUserCreated: Bool = false, authorName: String? = nil, createdAt: Date = Date()) {
        self.id = id
        self.title = title
        self.description = description
        self.titleRu = titleRu
        self.descriptionRu = descriptionRu
        self.titleFr = titleFr
        self.descriptionFr = descriptionFr
        self.titleEs = titleEs
        self.descriptionEs = descriptionEs
        self.titlePt = titlePt
        self.descriptionPt = descriptionPt
        self.titleZh = titleZh
        self.descriptionZh = descriptionZh
        self.category = category
        self.isFavorite = isFavorite
        self.userComment = userComment
        self.isUserCreated = isUserCreated
        self.authorName = authorName
        self.createdAt = createdAt
    }
    
    func getTitle(for language: String) -> String {
        switch language {
        case "ru": return titleRu ?? title
        case "fr": return titleFr ?? title
        case "es": return titleEs ?? title
        case "pt": return titlePt ?? title
        case "zh": return titleZh ?? title
        default: return title
        }
    }
    
    func getDescription(for language: String) -> String {
        switch language {
        case "ru": return descriptionRu ?? description
        case "fr": return descriptionFr ?? description
        case "es": return descriptionEs ?? description
        case "pt": return descriptionPt ?? description
        case "zh": return descriptionZh ?? description
        default: return description
        }
    }
}

class DateIdeasData: ObservableObject {
    @Published var ideas: [DateIdea] = []
    
    init() {
        loadIdeas()
        loadComments()
    }
    
    func loadIdeas() {
        ideas = generateAllIdeas()
    }
    
    func toggleFavorite(_ idea: DateIdea) {
        if let index = ideas.firstIndex(where: { $0.id == idea.id }) {
            ideas[index].isFavorite.toggle()
        }
    }
    
    func updateComment(_ idea: DateIdea, comment: String?) {
        if let index = ideas.firstIndex(where: { $0.id == idea.id }) {
            ideas[index].userComment = comment
            saveComments()
        }
    }
    
    private func saveComments() {
        // Сохраняем комментарии в UserDefaults
        var comments: [String: String] = [:]
        for idea in ideas {
            if let comment = idea.userComment {
                comments[idea.id.uuidString] = comment
            }
        }
        if let encoded = try? JSONEncoder().encode(comments) {
            UserDefaults.standard.set(encoded, forKey: "DateIdeasComments")
        }
    }
    
    private func loadComments() {
        // Загружаем комментарии из UserDefaults
        if let data = UserDefaults.standard.data(forKey: "DateIdeasComments"),
           let commentsDict = try? JSONDecoder().decode([String: String].self, from: data) {
            for i in 0..<ideas.count {
                if let comment = commentsDict[ideas[i].id.uuidString] {
                    ideas[i].userComment = comment
                }
            }
        }
    }
    
    func getRandomIdea(from category: DateIdeaCategory? = nil) -> DateIdea? {
        let filteredIdeas = category != nil ? ideas.filter { $0.category == category } : ideas
        return filteredIdeas.randomElement()
    }
    
    func addIdea(_ idea: DateIdea) {
        ideas.append(idea)
        saveComments()
    }
    
    private func generateAllIdeas() -> [DateIdea] {
        var allIdeas: [DateIdea] = []
        
        // Classic ideas with translations
        let classicIdeas = [
            DateIdea(
                title: "Dinner at a restaurant",
                description: "Enjoy a romantic dinner at a nice restaurant with candlelight and good wine.",
                titleRu: "Ужин в ресторане",
                descriptionRu: "Насладитесь романтическим ужином в хорошем ресторане при свечах и с хорошим вином.",
                titleFr: "Dîner au restaurant",
                descriptionFr: "Profitez d'un dîner romantique dans un bon restaurant aux chandelles avec un bon vin.",
                titleEs: "Cena en un restaurante",
                descriptionEs: "Disfruta de una cena romántica en un buen restaurante con velas y buen vino.",
                titlePt: "Jantar em um restaurante",
                descriptionPt: "Desfrute de um jantar romântico em um bom restaurante com velas e bom vinho.",
                titleZh: "在餐厅用餐",
                descriptionZh: "在温馨的餐厅享受浪漫晚餐，烛光与美酒相伴。",
                category: .classic
            ),
            DateIdea(
                title: "Movie night",
                description: "Watch a romantic movie together, either at the cinema or at home with popcorn.",
                titleRu: "Киновечер",
                descriptionRu: "Посмотрите вместе романтический фильм в кинотеатре или дома с попкорном.",
                titleFr: "Soirée cinéma",
                descriptionFr: "Regardez un film romantique ensemble, soit au cinéma, soit à la maison avec du pop-corn.",
                titleEs: "Noche de cine",
                descriptionEs: "Vean juntos una película romántica en el cine o en casa con palomitas.",
                titlePt: "Noite de cinema",
                descriptionPt: "Assistam a um filme romântico juntos, no cinema ou em casa com pipoca.",
                titleZh: "电影之夜",
                descriptionZh: "一起看一部浪漫电影，在电影院或在家配爆米花。",
                category: .classic
            ),
            DateIdea(
                title: "Walk in the park",
                description: "Take a leisurely walk in a beautiful park, hand in hand, enjoying nature.",
                titleRu: "Прогулка в парке",
                descriptionRu: "Совершите неспешную прогулку в красивом парке, держась за руки, наслаждаясь природой.",
                titleFr: "Promenade dans le parc",
                descriptionFr: "Faites une promenade tranquille dans un beau parc, main dans la main, en profitant de la nature.",
                titleEs: "Caminata en el parque",
                descriptionEs: "Den un paseo tranquilo en un hermoso parque, de la mano, disfrutando de la naturaleza.",
                titlePt: "Caminhada no parque",
                descriptionPt: "Façam uma caminhada tranquila em um belo parque, de mãos dadas, aproveitando a natureza.",
                titleZh: "公园散步",
                descriptionZh: "在美丽的公园里悠闲地散步，手牵着手，享受大自然。",
                category: .classic
            ),
            DateIdea(
                title: "Coffee date",
                description: "Visit a cozy café, chat over coffee, and enjoy each other's company.",
                titleRu: "Кофейное свидание",
                descriptionRu: "Посетите уютное кафе, поболтайте за кофе и насладитесь обществом друг друга.",
                titleFr: "Rendez-vous café",
                descriptionFr: "Visitez un café confortable, discutez autour d'un café et profitez de la compagnie l'un de l'autre.",
                titleEs: "Cita de café",
                descriptionEs: "Visiten un acogedor café, charlen tomando café y disfruten de la compañía mutua.",
                titlePt: "Encontro no café",
                descriptionPt: "Visitem um café aconchegante, conversem tomando café e desfrutem da companhia um do outro.",
                titleZh: "咖啡约会",
                descriptionZh: "去一家舒适的咖啡馆，边喝咖啡边聊天，享受彼此的陪伴。",
                category: .classic
            ),
            DateIdea(
                title: "Picnic",
                description: "Pack a basket with your favorite foods and have a picnic in a scenic location.",
                titleRu: "Пикник",
                descriptionRu: "Соберите корзину с любимыми блюдами и устройте пикник в живописном месте.",
                titleFr: "Pique-nique",
                descriptionFr: "Préparez un panier avec vos plats préférés et faites un pique-nique dans un endroit pittoresque.",
                titleEs: "Picnic",
                descriptionEs: "Preparen una canasta con sus comidas favoritas y tengan un picnic en un lugar pintoresco.",
                titlePt: "Piquenique",
                descriptionPt: "Preparem uma cesta com suas comidas favoritas e façam um piquenique em um local pitoresco.",
                titleZh: "野餐",
                descriptionZh: "准备一篮子你最喜欢的食物，在风景优美的地方野餐。",
                category: .classic
            ),
            DateIdea(
                title: "Museum visit",
                description: "Explore an art museum or gallery together and discuss your favorite pieces.",
                titleRu: "Посещение музея",
                descriptionRu: "Исследуйте вместе художественный музей или галерею и обсудите любимые произведения.",
                titleFr: "Visite de musée",
                descriptionFr: "Explorez ensemble un musée d'art ou une galerie et discutez de vos œuvres préférées.",
                titleEs: "Visita al museo",
                descriptionEs: "Exploren juntos un museo de arte o una galería y discutan sus piezas favoritas.",
                titlePt: "Visita ao museu",
                descriptionPt: "Explorem juntos um museu de arte ou galeria e discutam suas peças favoritas.",
                titleZh: "参观博物馆",
                descriptionZh: "一起探索艺术博物馆或画廊，讨论你们最喜欢的作品。",
                category: .classic
            ),
            DateIdea(
                title: "Concert or show",
                description: "Attend a live concert, theater performance, or musical together.",
                titleRu: "Концерт или шоу",
                descriptionRu: "Посетите вместе живой концерт, театральное представление или мюзикл.",
                titleFr: "Concert ou spectacle",
                descriptionFr: "Assistez ensemble à un concert live, une représentation théâtrale ou une comédie musicale.",
                titleEs: "Concierto o espectáculo",
                descriptionEs: "Asistan juntos a un concierto en vivo, una obra de teatro o un musical.",
                titlePt: "Show ou concerto",
                descriptionPt: "Assistam juntos a um show ao vivo, uma peça de teatro ou um musical.",
                titleZh: "音乐会或演出",
                descriptionZh: "一起参加现场音乐会、戏剧表演或音乐剧。",
                category: .classic
            ),
            DateIdea(
                title: "Beach day",
                description: "Spend a day at the beach, swimming, sunbathing, and building sandcastles.",
                titleRu: "День на пляже",
                descriptionRu: "Проведите день на пляже: плавайте, загорайте и стройте песочные замки.",
                titleFr: "Journée à la plage",
                descriptionFr: "Passez une journée à la plage, nagez, prenez le soleil et construisez des châteaux de sable.",
                titleEs: "Día en la playa",
                descriptionEs: "Pasen un día en la playa, nadando, tomando el sol y construyendo castillos de arena.",
                titlePt: "Dia na praia",
                descriptionPt: "Passem um dia na praia, nadando, tomando sol e construindo castelos de areia.",
                titleZh: "海滩日",
                descriptionZh: "在海滩度过一天，游泳、日光浴和堆沙堡。",
                category: .classic
            ),
            DateIdea(
                title: "Shopping together",
                description: "Go shopping together, help each other pick out clothes, and enjoy the experience.",
                titleRu: "Шопинг вместе",
                descriptionRu: "Сходите вместе за покупками, помогите друг другу выбрать одежду и насладитесь процессом.",
                titleFr: "Shopping ensemble",
                descriptionFr: "Allez faire du shopping ensemble, aidez-vous mutuellement à choisir des vêtements et profitez de l'expérience.",
                titleEs: "Ir de compras juntos",
                descriptionEs: "Vayan de compras juntos, ayúdense mutuamente a elegir ropa y disfruten de la experiencia.",
                titlePt: "Compras juntos",
                descriptionPt: "Façam compras juntos, ajudem-se mutuamente a escolher roupas e desfrutem da experiência.",
                titleZh: "一起购物",
                descriptionZh: "一起去购物，互相帮助挑选衣服，享受这个过程。",
                category: .classic
            ),
            DateIdea(
                title: "Cooking together",
                description: "Cook a meal together at home, trying a new recipe and enjoying the process.",
                titleRu: "Готовка вместе",
                descriptionRu: "Приготовьте вместе блюдо дома, попробуйте новый рецепт и насладитесь процессом.",
                titleFr: "Cuisiner ensemble",
                descriptionFr: "Cuisinez ensemble à la maison, essayez une nouvelle recette et profitez du processus.",
                titleEs: "Cocinar juntos",
                descriptionEs: "Cocinen juntos en casa, prueben una nueva receta y disfruten del proceso.",
                titlePt: "Cozinhar juntos",
                descriptionPt: "Cozinhem juntos em casa, experimentem uma nova receita e desfrutem do processo.",
                titleZh: "一起做饭",
                descriptionZh: "在家一起做饭，尝试新食谱，享受这个过程。",
                category: .classic
            ),
        ]
        
        // Romantic ideas with translations
        let romanticIdeas = [
            DateIdea(title: "Stargazing", description: "Find a quiet spot away from city lights and watch the stars together.", titleRu: "Наблюдение за звездами", descriptionRu: "Найдите тихое место вдали от городских огней и вместе наблюдайте за звездами.", titleFr: "Observation des étoiles", descriptionFr: "Trouvez un endroit calme loin des lumières de la ville et regardez les étoiles ensemble.", titleEs: "Observación de estrellas", descriptionEs: "Encuentren un lugar tranquilo lejos de las luces de la ciudad y observen las estrellas juntos.", titlePt: "Observação de estrelas", descriptionPt: "Encontrem um lugar tranquilo longe das luzes da cidade e observem as estrelas juntos.", titleZh: "观星", descriptionZh: "找一个远离城市灯光的安静地方，一起看星星。", category: .romantic),
            DateIdea(title: "Sunset watching", description: "Watch the sunset together from a beautiful viewpoint, perhaps with a blanket and snacks.", titleRu: "Наблюдение за закатом", descriptionRu: "Вместе наблюдайте за закатом с красивой смотровой площадки, возможно, с пледом и закусками.", titleFr: "Observation du coucher de soleil", descriptionFr: "Regardez le coucher de soleil ensemble depuis un bel endroit, peut-être avec une couverture et des collations.", titleEs: "Observación del atardecer", descriptionEs: "Observen juntos el atardecer desde un hermoso mirador, tal vez con una manta y bocadillos.", titlePt: "Observação do pôr do sol", descriptionPt: "Observem o pôr do sol juntos de um belo mirante, talvez com um cobertor e lanches.", titleZh: "看日落", descriptionZh: "从美丽的观景点一起看日落，也许带上毯子和零食。", category: .romantic),
            DateIdea(title: "Couple's spa day", description: "Book a couples massage or spa treatment and relax together.", titleRu: "Спа-день для пары", descriptionRu: "Забронируйте массаж для пары или спа-процедуру и расслабьтесь вместе.", titleFr: "Journée spa en couple", descriptionFr: "Réservez un massage en couple ou un traitement spa et détendez-vous ensemble.", titleEs: "Día de spa en pareja", descriptionEs: "Reserven un masaje en pareja o un tratamiento de spa y relájense juntos.", titlePt: "Dia de spa para casal", descriptionPt: "Reservem uma massagem para casal ou tratamento de spa e relaxem juntos.", titleZh: "情侣水疗日", descriptionZh: "预订情侣按摩或水疗护理，一起放松。", category: .romantic),
            DateIdea(title: "Romantic dinner at home", description: "Cook a special meal together, set the table beautifully, and enjoy a candlelit dinner.", titleRu: "Романтический ужин дома", descriptionRu: "Приготовьте вместе особое блюдо, красиво накройте стол и насладитесь ужином при свечах.", titleFr: "Dîner romantique à la maison", descriptionFr: "Cuisinez un repas spécial ensemble, dressez une belle table et profitez d'un dîner aux chandelles.", titleEs: "Cena romántica en casa", descriptionEs: "Cocinen una comida especial juntos, pongan una mesa hermosa y disfruten de una cena con velas.", titlePt: "Jantar romântico em casa", descriptionPt: "Cozinhem uma refeição especial juntos, arrumem uma mesa bonita e desfrutem de um jantar à luz de velas.", titleZh: "在家浪漫晚餐", descriptionZh: "一起做一顿特别的饭菜，精心布置餐桌，享受烛光晚餐。", category: .romantic),
            DateIdea(title: "Dance under the stars", description: "Find an open space, play your favorite music, and dance together under the night sky.", titleRu: "Танцы под звездами", descriptionRu: "Найдите открытое пространство, включите любимую музыку и танцуйте вместе под ночным небом.", titleFr: "Danser sous les étoiles", descriptionFr: "Trouvez un espace ouvert, jouez votre musique préférée et dansez ensemble sous le ciel nocturne.", titleEs: "Bailar bajo las estrellas", descriptionEs: "Encuentren un espacio abierto, pongan su música favorita y bailen juntos bajo el cielo nocturno.", titlePt: "Dançar sob as estrelas", descriptionPt: "Encontrem um espaço aberto, toquem sua música favorita e dancem juntos sob o céu noturno.", titleZh: "星空下共舞", descriptionZh: "找一个开阔的地方，播放你们最喜欢的音乐，在夜空下一起跳舞。", category: .romantic),
            DateIdea(title: "Love letter exchange", description: "Write love letters to each other and read them together in a special place.", titleRu: "Обмен любовными письмами", descriptionRu: "Напишите друг другу любовные письма и прочитайте их вместе в особом месте.", titleFr: "Échange de lettres d'amour", descriptionFr: "Écrivez-vous des lettres d'amour et lisez-les ensemble dans un endroit spécial.", titleEs: "Intercambio de cartas de amor", descriptionEs: "Escríbanse cartas de amor y léanlas juntos en un lugar especial.", titlePt: "Troca de cartas de amor", descriptionPt: "Escrevam cartas de amor um para o outro e leiam-nas juntos em um lugar especial.", titleZh: "交换情书", descriptionZh: "互相写情书，在一个特别的地方一起读。", category: .romantic),
            DateIdea(title: "Wine tasting", description: "Visit a winery or have a wine tasting at home, trying different wines together.", titleRu: "Дегустация вин", descriptionRu: "Посетите винодельню или устройте дегустацию вин дома, пробуя разные вина вместе.", titleFr: "Dégustation de vin", descriptionFr: "Visitez une cave à vin ou organisez une dégustation de vin à la maison, en essayant différents vins ensemble.", titleEs: "Cata de vinos", descriptionEs: "Visiten una bodega o tengan una cata de vinos en casa, probando diferentes vinos juntos.", titlePt: "Degustação de vinhos", descriptionPt: "Visitem uma vinícola ou façam uma degustação de vinhos em casa, experimentando diferentes vinhos juntos.", titleZh: "品酒", descriptionZh: "参观酒庄或在家品酒，一起尝试不同的葡萄酒。", category: .romantic),
            DateIdea(title: "Hot air balloon ride", description: "Take a romantic hot air balloon ride and enjoy breathtaking views together.", titleRu: "Полет на воздушном шаре", descriptionRu: "Совершите романтический полет на воздушном шаре и вместе насладитесь захватывающими видами.", titleFr: "Balade en montgolfière", descriptionFr: "Faites une balade romantique en montgolfière et profitez ensemble de vues à couper le souffle.", titleEs: "Paseo en globo aerostático", descriptionEs: "Tomen un paseo romántico en globo aerostático y disfruten juntos de vistas impresionantes.", titlePt: "Passeio de balão", descriptionPt: "Façam um passeio romântico de balão e desfrutem juntos de vistas deslumbrantes.", titleZh: "热气球之旅", descriptionZh: "乘坐浪漫的热气球，一起欣赏令人叹为观止的景色。", category: .romantic),
            DateIdea(title: "Boat ride", description: "Rent a boat or take a boat tour, enjoying the water and each other's company.", titleRu: "Прогулка на лодке", descriptionRu: "Арендуйте лодку или отправьтесь на лодочную экскурсию, наслаждаясь водой и обществом друг друга.", titleFr: "Promenade en bateau", descriptionFr: "Louez un bateau ou faites une excursion en bateau, en profitant de l'eau et de la compagnie l'un de l'autre.", titleEs: "Paseo en barco", descriptionEs: "Alquilen un barco o tomen un paseo en barco, disfrutando del agua y de la compañía mutua.", titlePt: "Passeio de barco", descriptionPt: "Aluguem um barco ou façam um passeio de barco, desfrutando da água e da companhia um do outro.", titleZh: "乘船游览", descriptionZh: "租一艘船或乘船游览，享受水景和彼此的陪伴。", category: .romantic),
            DateIdea(title: "Romantic getaway", description: "Plan a weekend trip to a romantic destination, just the two of you.", titleRu: "Романтическое путешествие", descriptionRu: "Спланируйте поездку на выходные в романтическое место, только вы вдвоем.", titleFr: "Évasion romantique", descriptionFr: "Planifiez un voyage de week-end dans une destination romantique, juste tous les deux.", titleEs: "Escape romántico", descriptionEs: "Planeen un viaje de fin de semana a un destino romántico, solo ustedes dos.", titlePt: "Fuga romântica", descriptionPt: "Planejem uma viagem de fim de semana para um destino romântico, apenas vocês dois.", titleZh: "浪漫之旅", descriptionZh: "计划一个周末的浪漫目的地之旅，只有你们两个人。", category: .romantic),
        ]
        
        // Adventurous ideas with translations
        let adventurousIdeas = [
            DateIdea(title: "Hiking adventure", description: "Go hiking on a scenic trail, explore nature, and enjoy the adventure together.", titleRu: "Поход", descriptionRu: "Отправьтесь в поход по живописной тропе, исследуйте природу и вместе насладитесь приключением.", titleFr: "Randonnée", descriptionFr: "Allez faire une randonnée sur un sentier pittoresque, explorez la nature et profitez de l'aventure ensemble.", titleEs: "Senderismo", descriptionEs: "Vayan de senderismo por un sendero pintoresco, exploren la naturaleza y disfruten de la aventura juntos.", titlePt: "Trilha", descriptionPt: "Façam uma trilha em uma trilha pitoresca, explorem a natureza e desfrutem da aventura juntos.", titleZh: "徒步旅行", descriptionZh: "沿着风景优美的小径徒步，探索大自然，一起享受冒险。", category: .adventurous),
            DateIdea(title: "Rock climbing", description: "Try indoor or outdoor rock climbing together and support each other.", titleRu: "Скалолазание", descriptionRu: "Попробуйте вместе скалолазание в помещении или на открытом воздухе и поддерживайте друг друга.", titleFr: "Escalade", descriptionFr: "Essayez l'escalade en salle ou en extérieur ensemble et soutenez-vous mutuellement.", titleEs: "Escalada", descriptionEs: "Prueben la escalada en interiores o al aire libre juntos y apóyense mutuamente.", titlePt: "Escalada", descriptionPt: "Experimentem escalada indoor ou ao ar livre juntos e apoiem-se mutuamente.", titleZh: "攀岩", descriptionZh: "一起尝试室内或室外攀岩，互相支持。", category: .adventurous),
            DateIdea(title: "Water sports", description: "Try kayaking, paddleboarding, or surfing together for an active date.", titleRu: "Водные виды спорта", descriptionRu: "Попробуйте вместе каякинг, паддлбординг или серфинг для активного свидания.", titleFr: "Sports nautiques", descriptionFr: "Essayez le kayak, le paddle ou le surf ensemble pour un rendez-vous actif.", titleEs: "Deportes acuáticos", descriptionEs: "Prueben kayak, paddle surf o surf juntos para una cita activa.", titlePt: "Esportes aquáticos", descriptionPt: "Experimentem caiaque, stand-up paddle ou surf juntos para um encontro ativo.", titleZh: "水上运动", descriptionZh: "一起尝试皮划艇、桨板或冲浪，来一次活跃的约会。", category: .adventurous),
            DateIdea(title: "Escape room", description: "Solve puzzles together in an escape room and work as a team.", titleRu: "Квест-комната", descriptionRu: "Вместе решайте головоломки в квест-комнате и работайте в команде.", titleFr: "Escape game", descriptionFr: "Résolvez des énigmes ensemble dans une escape room et travaillez en équipe.", titleEs: "Sala de escape", descriptionEs: "Resuelvan acertijos juntos en una sala de escape y trabajen en equipo.", titlePt: "Sala de fuga", descriptionPt: "Resolvam quebra-cabeças juntos em uma sala de fuga e trabalhem em equipe.", titleZh: "密室逃脱", descriptionZh: "在密室逃脱中一起解谜，团队合作。", category: .adventurous),
            DateIdea(title: "Amusement park", description: "Spend a day at an amusement park, ride roller coasters, and have fun together.", titleRu: "Парк развлечений", descriptionRu: "Проведите день в парке развлечений, катайтесь на американских горках и веселитесь вместе.", titleFr: "Parc d'attractions", descriptionFr: "Passez une journée dans un parc d'attractions, montez sur des montagnes russes et amusez-vous ensemble.", titleEs: "Parque de atracciones", descriptionEs: "Pasen un día en un parque de atracciones, monten en montañas rusas y diviértanse juntos.", titlePt: "Parque de diversões", descriptionPt: "Passem um dia em um parque de diversões, andem em montanhas-russas e divirtam-se juntos.", titleZh: "游乐园", descriptionZh: "在游乐园度过一天，乘坐过山车，一起享受乐趣。", category: .adventurous),
            DateIdea(title: "Bike ride", description: "Go on a bike ride together, exploring new areas and enjoying the exercise.", titleRu: "Велосипедная прогулка", descriptionRu: "Отправьтесь вместе на велосипедную прогулку, исследуя новые места и наслаждаясь физической активностью.", titleFr: "Balade à vélo", descriptionFr: "Allez faire une balade à vélo ensemble, explorez de nouveaux endroits et profitez de l'exercice.", titleEs: "Paseo en bicicleta", descriptionEs: "Vayan juntos en bicicleta, exploren nuevas áreas y disfruten del ejercicio.", titlePt: "Passeio de bicicleta", descriptionPt: "Façam um passeio de bicicleta juntos, explorando novas áreas e desfrutando do exercício.", titleZh: "骑自行车", descriptionZh: "一起骑自行车，探索新区域，享受运动。", category: .adventurous),
            DateIdea(title: "Camping trip", description: "Plan a camping trip, set up a tent, make a campfire, and enjoy nature.", titleRu: "Поход с палаткой", descriptionRu: "Спланируйте поход с палаткой, установите палатку, разведите костер и насладитесь природой.", titleFr: "Camping", descriptionFr: "Planifiez un camping, montez une tente, faites un feu de camp et profitez de la nature.", titleEs: "Camping", descriptionEs: "Planeen un viaje de camping, monten una tienda, hagan una fogata y disfruten de la naturaleza.", titlePt: "Acampamento", descriptionPt: "Planejem um acampamento, montem uma barraca, façam uma fogueira e desfrutem da natureza.", titleZh: "露营", descriptionZh: "计划一次露营，搭帐篷，生篝火，享受大自然。", category: .adventurous),
            DateIdea(title: "Ziplining", description: "Try ziplining together for an adrenaline-filled adventure.", titleRu: "Зиплайнинг", descriptionRu: "Попробуйте вместе зиплайнинг для полного адреналина приключения.", titleFr: "Tyrolienne", descriptionFr: "Essayez la tyrolienne ensemble pour une aventure pleine d'adrénaline.", titleEs: "Tirolesa", descriptionEs: "Prueben la tirolesa juntos para una aventura llena de adrenalina.", titlePt: "Tirolesa", descriptionPt: "Experimentem tirolesa juntos para uma aventura cheia de adrenalina.", titleZh: "滑索", descriptionZh: "一起尝试滑索，体验充满肾上腺素的冒险。", category: .adventurous),
            DateIdea(title: "Scavenger hunt", description: "Create a scavenger hunt for each other with clues and surprises.", titleRu: "Охота за сокровищами", descriptionRu: "Создайте друг для друга охоту за сокровищами с подсказками и сюрпризами.", titleFr: "Chasse au trésor", descriptionFr: "Créez une chasse au trésor l'un pour l'autre avec des indices et des surprises.", titleEs: "Búsqueda del tesoro", descriptionEs: "Creen una búsqueda del tesoro el uno para el otro con pistas y sorpresas.", titlePt: "Caça ao tesouro", descriptionPt: "Criem uma caça ao tesouro um para o outro com pistas e surpresas.", titleZh: "寻宝游戏", descriptionZh: "为彼此创建一个寻宝游戏，包含线索和惊喜。", category: .adventurous),
            DateIdea(title: "Bungee jumping", description: "For the truly adventurous, try bungee jumping together and share the thrill.", titleRu: "Банджи-джампинг", descriptionRu: "Для настоящих искателей приключений попробуйте вместе банджи-джампинг и разделите острые ощущения.", titleFr: "Saut à l'élastique", descriptionFr: "Pour les vraiment aventureux, essayez le saut à l'élastique ensemble et partagez le frisson.", titleEs: "Puenting", descriptionEs: "Para los verdaderamente aventureros, prueben el puenting juntos y compartan la emoción.", titlePt: "Bungee jumping", descriptionPt: "Para os verdadeiramente aventureiros, experimentem bungee jumping juntos e compartilhem a emoção.", titleZh: "蹦极", descriptionZh: "对于真正的冒险者，一起尝试蹦极，分享刺激。", category: .adventurous),
        ]
        
        // Creative ideas
        let creativeIdeas = [
            DateIdea(title: "Art class together", description: "Take a painting, pottery, or art class together and create something beautiful.", category: .creative),
            DateIdea(title: "Photography walk", description: "Go on a photography walk, taking pictures of interesting things and each other.", category: .creative),
            DateIdea(title: "Write a story together", description: "Collaborate on writing a short story, taking turns adding to the narrative.", category: .creative),
            DateIdea(title: "Karaoke night", description: "Sing your hearts out at a karaoke bar or at home with a karaoke machine.", category: .creative),
            DateIdea(title: "DIY project", description: "Work on a DIY project together, building or creating something for your home.", category: .creative),
            DateIdea(title: "Comedy show", description: "Attend a stand-up comedy show or open mic night and laugh together.", category: .creative),
            DateIdea(title: "Craft workshop", description: "Attend a craft workshop together, learning a new skill and creating something.", category: .creative),
            DateIdea(title: "Music jam session", description: "Play music together, whether you're both musicians or just having fun with instruments.", category: .creative),
            DateIdea(title: "Theater workshop", description: "Take an acting or theater workshop together and have fun performing.", category: .creative),
            DateIdea(title: "Design challenge", description: "Give each other a design challenge and create something based on a theme.", category: .creative),
        ]
        
        // Cozy ideas
        let cozyIdeas = [
            DateIdea(title: "Home movie marathon", description: "Pick a movie series or theme and watch movies all day, cuddled up on the couch.", category: .cozy),
            DateIdea(title: "Board game night", description: "Play board games together, from classics to modern strategy games.", category: .cozy),
            DateIdea(title: "Baking together", description: "Bake cookies, cakes, or bread together and enjoy the delicious results.", category: .cozy),
            DateIdea(title: "Reading together", description: "Read a book together, taking turns reading chapters aloud to each other.", category: .cozy),
            DateIdea(title: "Puzzle night", description: "Work on a jigsaw puzzle together while chatting and enjoying each other's company.", category: .cozy),
            DateIdea(title: "Home spa day", description: "Create a spa experience at home with face masks, massages, and relaxation.", category: .cozy),
            DateIdea(title: "Video game night", description: "Play video games together, either cooperatively or competitively.", category: .cozy),
            DateIdea(title: "Candlelit bath", description: "Take a relaxing bath together with candles, music, and maybe some wine.", category: .cozy),
            DateIdea(title: "Breakfast in bed", description: "Make breakfast together and enjoy it in bed, starting the day slowly.", category: .cozy),
            DateIdea(title: "Fireplace evening", description: "Light a fire (or use a fireplace app), cuddle up with blankets, and talk.", category: .cozy),
        ]
        
        // Unusual ideas
        let unusualIdeas = [
            DateIdea(title: "Ghost tour", description: "Take a ghost tour or haunted house tour together for a spooky adventure.", category: .unusual),
            DateIdea(title: "Volunteer together", description: "Spend time volunteering at a local charity or organization together.", category: .unusual),
            DateIdea(title: "Food truck crawl", description: "Visit multiple food trucks in one evening, trying different cuisines.", category: .unusual),
            DateIdea(title: "Thrift store challenge", description: "Give each other a budget and find the most interesting items at thrift stores.", category: .unusual),
            DateIdea(title: "Planetarium visit", description: "Visit a planetarium and learn about the stars and universe together.", category: .unusual),
            DateIdea(title: "Farm visit", description: "Visit a local farm, pick fruits or vegetables, and learn about farming.", category: .unusual),
            DateIdea(title: "Bookstore date", description: "Spend time in a bookstore, picking out books for each other and reading together.", category: .unusual),
            DateIdea(title: "Night market", description: "Explore a night market, trying street food and browsing unique items.", category: .unusual),
            DateIdea(title: "Archery or axe throwing", description: "Try archery or axe throwing together for a unique and fun experience.", category: .unusual),
            DateIdea(title: "Sunrise breakfast", description: "Wake up early to watch the sunrise together and have breakfast at dawn.", category: .unusual),
        ]
        
        allIdeas.append(contentsOf: classicIdeas)
        allIdeas.append(contentsOf: romanticIdeas)
        allIdeas.append(contentsOf: adventurousIdeas)
        allIdeas.append(contentsOf: creativeIdeas)
        allIdeas.append(contentsOf: cozyIdeas)
        allIdeas.append(contentsOf: unusualIdeas)
        
        return allIdeas
    }
}

