//
//  LovePhrase.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import Foundation

enum LoveCategory: String, CaseIterable, Identifiable, Codable {
    case intellectual = "Интеллектуальные"
    case absurd = "Абсурдные"
    case poetic = "Поэтические"
    case bold = "Дерзкие"
    case cozy = "Уютные"
    case romantic = "Романтические"
    case funny = "Смешные"
    case deep = "Глубокие"
    case everyday = "Повседневные"
    case creative = "Креативные"
    
    var id: String { rawValue }
    
    func localizedName(language: String) -> String {
        switch language {
        case "en":
            switch self {
            case .intellectual: return "Intellectual"
            case .absurd: return "Absurd"
            case .poetic: return "Poetic"
            case .bold: return "Bold"
            case .cozy: return "Cozy"
            case .romantic: return "Romantic"
            case .funny: return "Funny"
            case .deep: return "Deep"
            case .everyday: return "Everyday"
            case .creative: return "Creative"
            }
        case "fr":
            switch self {
            case .intellectual: return "Intellectuel"
            case .absurd: return "Absurde"
            case .poetic: return "Poétique"
            case .bold: return "Audacieux"
            case .cozy: return "Confortable"
            case .romantic: return "Romantique"
            case .funny: return "Drôle"
            case .deep: return "Profond"
            case .everyday: return "Quotidien"
            case .creative: return "Créatif"
            }
        case "es":
            switch self {
            case .intellectual: return "Intelectual"
            case .absurd: return "Absurdo"
            case .poetic: return "Poético"
            case .bold: return "Audaz"
            case .cozy: return "Acogedor"
            case .romantic: return "Romántico"
            case .funny: return "Divertido"
            case .deep: return "Profundo"
            case .everyday: return "Cotidiano"
            case .creative: return "Creativo"
            }
        case "pt":
            switch self {
            case .intellectual: return "Intelectual"
            case .absurd: return "Absurdo"
            case .poetic: return "Poético"
            case .bold: return "Ousado"
            case .cozy: return "Aconchegante"
            case .romantic: return "Romântico"
            case .funny: return "Engraçado"
            case .deep: return "Profundo"
            case .everyday: return "Cotidiano"
            case .creative: return "Criativo"
            }
        case "zh":
            switch self {
            case .intellectual: return "智慧"
            case .absurd: return "荒诞"
            case .poetic: return "诗意"
            case .bold: return "大胆"
            case .cozy: return "舒适"
            case .romantic: return "浪漫"
            case .funny: return "有趣"
            case .deep: return "深刻"
            case .everyday: return "日常"
            case .creative: return "创意"
            }
        default:
            return rawValue
        }
    }
    
    var icon: String {
        switch self {
        case .intellectual: return "brain.head.profile"
        case .absurd: return "face.smiling"
        case .poetic: return "book.fill"
        case .bold: return "flame.fill"
        case .cozy: return "house.fill"
        case .romantic: return "heart.fill"
        case .funny: return "theatermasks.fill"
        case .deep: return "moon.stars.fill"
        case .everyday: return "cup.and.saucer.fill"
        case .creative: return "paintbrush.fill"
        }
    }
}

struct LovePhrase: Identifiable, Codable {
    let id: UUID
    let text: String
    let englishText: String?
    let frenchText: String?
    let spanishText: String?
    let portugueseText: String?
    let chineseText: String?
    let category: LoveCategory
    var isFavorite: Bool
    var userComment: String?
    
    init(id: UUID = UUID(), text: String, englishText: String? = nil, frenchText: String? = nil, spanishText: String? = nil, portugueseText: String? = nil, chineseText: String? = nil, category: LoveCategory, isFavorite: Bool = false, userComment: String? = nil) {
        self.id = id
        self.text = text
        self.englishText = englishText
        self.frenchText = frenchText
        self.spanishText = spanishText
        self.portugueseText = portugueseText
        self.chineseText = chineseText
        self.category = category
        self.isFavorite = isFavorite
        self.userComment = userComment
    }
    
    func getText(for language: String) -> String {
        switch language {
        case "en": return englishText ?? text
        case "fr": return frenchText ?? englishText ?? text
        case "es": return spanishText ?? englishText ?? text
        case "pt": return portugueseText ?? englishText ?? text
        case "zh": return chineseText ?? englishText ?? text
        default: return text
        }
    }
}

