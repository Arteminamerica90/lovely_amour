//
//  ContentView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var phrasesData = LovePhrasesData()
    @State private var selectedCategory: LoveCategory? = nil
    @State private var searchText = ""
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    @State private var showSettings = false
    @State private var selectedTab = 0
    @State private var showFavoritesOnly = false
    
    var currentLanguage: String {
        selectedLanguage
    }
    
    func languageFlag(for language: String) -> String {
        switch language {
        case "ru": return "🇷🇺"
        case "en": return "🇬🇧"
        case "fr": return "🇫🇷"
        case "es": return "🇪🇸"
        case "pt": return "🇵🇹"
        case "zh": return "🇨🇳"
        default: return "🇷🇺"
        }
    }
    
    var filteredPhrases: [LovePhrase] {
        var phrases = phrasesData.phrases
        
        if showFavoritesOnly {
            phrases = phrases.filter { $0.isFavorite }
        }
        
        if let category = selectedCategory {
            phrases = phrases.filter { $0.category == category }
        }
        
        if !searchText.isEmpty {
            phrases = phrases.filter { phrase in
                let textToSearch = phrase.getText(for: currentLanguage)
                return textToSearch.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        return phrases
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Phrases Tab
            phrasesTab
                .tabItem {
                    Image(systemName: "heart.text.square.fill")
                    Text(localizedPhrasesTab(for: selectedLanguage))
                }
                .tag(0)
            
            // History Tab
            HistoryView()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text(localizedHistoryTab(for: selectedLanguage))
                }
                .tag(1)
            
            // Date Ideas Tab
            DateIdeasView()
                .tabItem {
                    Image(systemName: "sparkles")
                    Text(localizedDateIdeasTab(for: selectedLanguage))
                }
                .tag(2)
            
            // Favorites Tab
            FavoritesView()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text(localizedFavoritesTab(for: selectedLanguage))
                }
                .tag(3)
        }
        .accentColor(Color(red: 0.2, green: 0.8, blue: 0.7))
    }
    
    var phrasesTab: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                colors: [
                    Color(red: 0.2, green: 0.8, blue: 0.7),
                    Color(red: 0.3, green: 0.9, blue: 0.6),
                    Color(red: 0.4, green: 0.85, blue: 0.65)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            // Decorative circles
            GeometryReader { geometry in
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.2),
                                Color.white.opacity(0.05)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 300, height: 300)
                    .blur(radius: 60)
                    .offset(x: -100, y: -100)
                
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.15),
                                Color.white.opacity(0.03)
                            ],
                            startPoint: .topTrailing,
                            endPoint: .bottomLeading
                        )
                    )
                    .frame(width: 250, height: 250)
                    .blur(radius: 50)
                    .offset(x: geometry.size.width - 150, y: geometry.size.height - 200)
                
                Ellipse()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.1),
                                Color.white.opacity(0.02)
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: 400, height: 200)
                    .blur(radius: 70)
                    .offset(x: geometry.size.width / 2 - 200, y: geometry.size.height / 2)
            }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    HStack {
                        Text("💕")
                            .font(.system(size: 40))
                        Text(localizedTitle(for: selectedLanguage))
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        Spacer()
                        HStack(spacing: 12) {
                            // Language switcher
                            Menu {
                                Button(action: {
                                    selectedLanguage = "ru"
                                }) {
                                    HStack {
                                        Text("🇷🇺 Русский")
                                        if selectedLanguage == "ru" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                                
                                Button(action: {
                                    selectedLanguage = "en"
                                }) {
                                    HStack {
                                        Text("🇬🇧 English")
                                        if selectedLanguage == "en" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                                
                                Button(action: {
                                    selectedLanguage = "fr"
                                }) {
                                    HStack {
                                        Text("🇫🇷 Français")
                                        if selectedLanguage == "fr" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                                
                                Button(action: {
                                    selectedLanguage = "es"
                                }) {
                                    HStack {
                                        Text("🇪🇸 Español")
                                        if selectedLanguage == "es" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                                
                                Button(action: {
                                    selectedLanguage = "pt"
                                }) {
                                    HStack {
                                        Text("🇵🇹 Português")
                                        if selectedLanguage == "pt" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                                
                                Button(action: {
                                    selectedLanguage = "zh"
                                }) {
                                    HStack {
                                        Text("🇨🇳 中文")
                                        if selectedLanguage == "zh" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            } label: {
                                Text(languageFlag(for: selectedLanguage))
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(
                                        Circle()
                                            .fill(.ultraThinMaterial)
                                    )
                            }
                            
                            Button(action: {
                                showFavoritesOnly.toggle()
                            }) {
                                Image(systemName: showFavoritesOnly ? "heart.fill" : "heart")
                                    .font(.title2)
                                    .foregroundColor(showFavoritesOnly ? .red : .white)
                            }
                            
                            Button(action: {
                                showSettings = true
                            }) {
                                Image(systemName: "gearshape.fill")
                                    .font(.title2)
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    
                    // Search bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white.opacity(0.7))
                        TextField(localizedSearchPlaceholder(for: selectedLanguage), text: $searchText)
                            .foregroundColor(.white)
                            .autocapitalization(.none)
                    }
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 16)
                
                // Category tabs
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                            CategoryTab(
                            category: nil,
                            selectedCategory: $selectedCategory,
                            icon: "star.fill",
                            title: localizedAll(for: selectedLanguage)
                        )
                        
                        ForEach(LoveCategory.allCases) { category in
                            CategoryTab(
                                category: category,
                                selectedCategory: $selectedCategory,
                                icon: category.icon,
                                title: category.localizedName(language: currentLanguage)
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 16)
                
                // Phrases list
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(filteredPhrases) { phrase in
                            PhraseCard(phrasesData: phrasesData, phrase: phrase, language: currentLanguage) {
                                phrasesData.toggleFavorite(phrase)
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Слова Любви"
        case "en": return "Words of Love"
        case "fr": return "Mots d'Amour"
        case "es": return "Palabras de Amor"
        case "pt": return "Palavras de Amor"
        case "zh": return "爱的词语"
        default: return "Слова Любви"
        }
    }
    
    func localizedSearchPlaceholder(for language: String) -> String {
        switch language {
        case "ru": return "Поиск..."
        case "en": return "Search..."
        case "fr": return "Rechercher..."
        case "es": return "Buscar..."
        case "pt": return "Pesquisar..."
        case "zh": return "搜索..."
        default: return "Поиск..."
        }
    }
    
    func localizedAll(for language: String) -> String {
        switch language {
        case "ru": return "Все"
        case "en": return "All"
        case "fr": return "Tous"
        case "es": return "Todos"
        case "pt": return "Todos"
        case "zh": return "全部"
        default: return "Все"
        }
    }
    
    func localizedPhrasesTab(for language: String) -> String {
        switch language {
        case "ru": return "Фразы"
        case "en": return "Phrases"
        case "fr": return "Phrases"
        case "es": return "Frases"
        case "pt": return "Frases"
        case "zh": return "短语"
        default: return "Фразы"
        }
    }
    
    func localizedHistoryTab(for language: String) -> String {
        switch language {
        case "ru": return "История"
        case "en": return "History"
        case "fr": return "Histoire"
        case "es": return "Historia"
        case "pt": return "História"
        case "zh": return "历史"
        default: return "История"
        }
    }
    
    func localizedDateIdeasTab(for language: String) -> String {
        switch language {
        case "ru": return "Идеи"
        case "en": return "Date Ideas"
        case "fr": return "Idées"
        case "es": return "Ideas"
        case "pt": return "Ideias"
        case "zh": return "想法"
        default: return "Идеи"
        }
    }
    
    func localizedFavoritesTab(for language: String) -> String {
        switch language {
        case "ru": return "Избранное"
        case "en": return "Favorites"
        case "fr": return "Favoris"
        case "es": return "Favoritos"
        case "pt": return "Favoritos"
        case "zh": return "收藏"
        default: return "Избранное"
        }
    }
}

struct CategoryTab: View {
    let category: LoveCategory?
    @Binding var selectedCategory: LoveCategory?
    let icon: String
    let title: String
    
    var isSelected: Bool {
        selectedCategory == category
    }
    
    var body: some View {
        Button(action: {
            selectedCategory = category
        }) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 14))
                Text(title)
                    .font(.system(size: 14, weight: .medium))
            }
            .foregroundColor(isSelected ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background {
                if isSelected {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                } else {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.clear)
                }
            }
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
        }
    }
}

struct PhraseCard: View {
    @ObservedObject var phrasesData: LovePhrasesData
    let phrase: LovePhrase
    let language: String
    let onFavoriteTap: () -> Void
    @State private var showCommentSheet = false
    
    var displayText: String {
        return phrase.getText(for: language)
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text(displayText)
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                
                if let comment = phrase.userComment, !comment.isEmpty {
                    Text(comment)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundColor(.white.opacity(0.8))
                        .italic()
                        .padding(.top, 4)
                }
                
                HStack {
                    Text(phrase.category.localizedName(language: language))
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white.opacity(0.7))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(
                            Capsule()
                                .fill(Color.white.opacity(0.2))
                        )
                    Spacer()
                }
            }
            
            VStack(spacing: 12) {
                Button(action: {
                    showCommentSheet = true
                }) {
                    Image(systemName: phrase.userComment != nil && !phrase.userComment!.isEmpty ? "text.bubble.fill" : "text.bubble")
                        .font(.title3)
                        .foregroundColor(phrase.userComment != nil && !phrase.userComment!.isEmpty ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white.opacity(0.7))
                }
                
                Button(action: onFavoriteTap) {
                    Image(systemName: phrase.isFavorite ? "heart.fill" : "heart")
                        .font(.title3)
                        .foregroundColor(phrase.isFavorite ? .red : .white.opacity(0.7))
                }
            }
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
        .sheet(isPresented: $showCommentSheet) {
            CommentView(
                text: phrase.userComment ?? "",
                onSave: { comment in
                    phrasesData.updateComment(phrase, comment: comment.isEmpty ? nil : comment)
                },
                language: language
            )
        }
    }
}


#Preview {
    ContentView()
}

