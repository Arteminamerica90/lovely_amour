//
//  HistoryView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct HistoryView: View {
    @StateObject private var storiesData = LoveStoriesData()
    @State private var showAddStory = false
    @State private var selectedStory: LoveStory?
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    @State private var showFavoritesOnly = false
    
    var filteredStories: [LoveStory] {
        var stories = storiesData.getStories(for: selectedLanguage)
        
        if showFavoritesOnly {
            stories = stories.filter { $0.isFavorite }
        }
        
        return stories
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.2, green: 0.8, blue: 0.7),
                    Color(red: 0.3, green: 0.9, blue: 0.6)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("💕")
                        .font(.system(size: 40))
                    Text(localizedTitle(for: selectedLanguage))
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Spacer()
                    HStack(spacing: 12) {
                        Button(action: {
                            showFavoritesOnly.toggle()
                        }) {
                            Image(systemName: showFavoritesOnly ? "heart.fill" : "heart")
                                .font(.title2)
                                .foregroundColor(showFavoritesOnly ? .red : .white)
                        }
                        
                        Button(action: {
                            showAddStory = true
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 16)
                
                // Stories list
                if filteredStories.isEmpty {
                    VStack(spacing: 20) {
                        Spacer()
                        Image(systemName: "book.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.white.opacity(0.7))
                        Text(localizedEmptyMessage(for: selectedLanguage))
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white.opacity(0.8))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                        Spacer()
                    }
                } else {
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(filteredStories.sorted(by: { $0.date > $1.date })) { story in
                                StoryCard(
                                    story: story,
                                    language: selectedLanguage,
                                    onTap: {
                                        selectedStory = story
                                    },
                                    onFavoriteTap: {
                                        storiesData.toggleFavorite(story)
                                    },
                                    onDelete: {
                                        storiesData.deleteStory(story)
                                    }
                                )
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                    }
                }
            }
        }
        .sheet(isPresented: $showAddStory) {
            AddStoryView(storiesData: storiesData, language: selectedLanguage)
        }
        .sheet(item: $selectedStory) { story in
            EditStoryView(story: story, storiesData: storiesData, language: selectedLanguage)
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Наша История"
        case "en": return "Our History"
        case "fr": return "Notre Histoire"
        case "es": return "Nuestra Historia"
        case "pt": return "Nossa História"
        case "zh": return "我们的历史"
        default: return "Наша История"
        }
    }
    
    func localizedEmptyMessage(for language: String) -> String {
        switch language {
        case "ru": return "Начните создавать вашу историю любви\nНажмите + чтобы добавить первую запись"
        case "en": return "Start creating your love story\nTap + to add your first entry"
        case "fr": return "Commencez à créer votre histoire d'amour\nAppuyez sur + pour ajouter votre première entrée"
        case "es": return "Comienza a crear tu historia de amor\nToca + para agregar tu primera entrada"
        case "pt": return "Comece a criar sua história de amor\nToque em + para adicionar sua primeira entrada"
        case "zh": return "开始创建你的爱情故事\n点击 + 添加你的第一条记录"
        default: return "Начните создавать вашу историю любви\nНажмите + чтобы добавить первую запись"
        }
    }
}

struct StoryCard: View {
    let story: LoveStory
    let language: String
    let onTap: () -> Void
    let onFavoriteTap: () -> Void
    let onDelete: () -> Void
    
    @State private var showDeleteAlert = false
    
    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(story.title)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Button(action: {
                        showDeleteAlert = true
                    }) {
                        Image(systemName: "trash")
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.7))
                    }
                }
                
                Text(story.content)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.white.opacity(0.9))
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
                
                HStack {
                    Text(formatDate(story.date, language: language))
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white.opacity(0.7))
                    Spacer()
                    Button(action: onFavoriteTap) {
                        Image(systemName: story.isFavorite ? "heart.fill" : "heart")
                            .font(.system(size: 16))
                            .foregroundColor(story.isFavorite ? .red : .white.opacity(0.7))
                    }
                }
            }
            .padding(20)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
        }
        .buttonStyle(PlainButtonStyle())
        .alert(localizedDeleteTitle(for: language), isPresented: $showDeleteAlert) {
            Button(localizedCancel(for: language), role: .cancel) { }
            Button(localizedDelete(for: language), role: .destructive) {
                onDelete()
            }
        } message: {
            Text(localizedDeleteMessage(for: language))
        }
    }
    
    func formatDate(_ date: Date, language: String) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: language == "ru" ? "ru_RU" : language == "zh" ? "zh_CN" : language == "fr" ? "fr_FR" : language == "es" ? "es_ES" : language == "pt" ? "pt_BR" : "en_US")
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    func localizedDeleteTitle(for language: String) -> String {
        switch language {
        case "ru": return "Удалить историю?"
        case "en": return "Delete story?"
        case "fr": return "Supprimer l'histoire?"
        case "es": return "¿Eliminar historia?"
        case "pt": return "Excluir história?"
        case "zh": return "删除故事？"
        default: return "Удалить историю?"
        }
    }
    
    func localizedDeleteMessage(for language: String) -> String {
        switch language {
        case "ru": return "Вы уверены, что хотите удалить эту историю?"
        case "en": return "Are you sure you want to delete this story?"
        case "fr": return "Êtes-vous sûr de vouloir supprimer cette histoire?"
        case "es": return "¿Estás seguro de que quieres eliminar esta historia?"
        case "pt": return "Tem certeza de que deseja excluir esta história?"
        case "zh": return "你确定要删除这个故事吗？"
        default: return "Вы уверены, что хотите удалить эту историю?"
        }
    }
    
    func localizedDelete(for language: String) -> String {
        switch language {
        case "ru": return "Удалить"
        case "en": return "Delete"
        case "fr": return "Supprimer"
        case "es": return "Eliminar"
        case "pt": return "Excluir"
        case "zh": return "删除"
        default: return "Удалить"
        }
    }
    
    func localizedCancel(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}

struct AddStoryView: View {
    @ObservedObject var storiesData: LoveStoriesData
    let language: String
    @Environment(\.dismiss) var dismiss
    
    @State private var title = ""
    @State private var content = ""
    @State private var selectedLanguage: String
    
    init(storiesData: LoveStoriesData, language: String) {
        self.storiesData = storiesData
        self.language = language
        _selectedLanguage = State(initialValue: language)
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(localizedTitleLabel(for: language))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        TextField(localizedTitlePlaceholder(for: language), text: $title)
                            .textFieldStyle(.plain)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text(localizedContentLabel(for: language))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        TextEditor(text: $content)
                            .frame(minHeight: 200)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(.white)
                            .scrollContentBackground(.hidden)
                    }
                    
                    Spacer()
                }
                .padding(20)
            }
            .navigationTitle(localizedNavTitle(for: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(localizedCancel(for: language)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedSave(for: language)) {
                        if !title.isEmpty && !content.isEmpty {
                            let story = LoveStory(title: title, content: content, language: selectedLanguage)
                            storiesData.addStory(story)
                            dismiss()
                        }
                    }
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .disabled(title.isEmpty || content.isEmpty)
                }
            }
        }
    }
    
    func localizedNavTitle(for language: String) -> String {
        switch language {
        case "ru": return "Новая история"
        case "en": return "New Story"
        case "fr": return "Nouvelle histoire"
        case "es": return "Nueva historia"
        case "pt": return "Nova história"
        case "zh": return "新故事"
        default: return "Новая история"
        }
    }
    
    func localizedTitleLabel(for language: String) -> String {
        switch language {
        case "ru": return "Заголовок"
        case "en": return "Title"
        case "fr": return "Titre"
        case "es": return "Título"
        case "pt": return "Título"
        case "zh": return "标题"
        default: return "Заголовок"
        }
    }
    
    func localizedTitlePlaceholder(for language: String) -> String {
        switch language {
        case "ru": return "Введите заголовок..."
        case "en": return "Enter title..."
        case "fr": return "Entrez le titre..."
        case "es": return "Ingrese el título..."
        case "pt": return "Digite o título..."
        case "zh": return "输入标题..."
        default: return "Введите заголовок..."
        }
    }
    
    func localizedContentLabel(for language: String) -> String {
        switch language {
        case "ru": return "Содержание"
        case "en": return "Content"
        case "fr": return "Contenu"
        case "es": return "Contenido"
        case "pt": return "Conteúdo"
        case "zh": return "内容"
        default: return "Содержание"
        }
    }
    
    func localizedSave(for language: String) -> String {
        switch language {
        case "ru": return "Сохранить"
        case "en": return "Save"
        case "fr": return "Enregistrer"
        case "es": return "Guardar"
        case "pt": return "Salvar"
        case "zh": return "保存"
        default: return "Сохранить"
        }
    }
    
    func localizedCancel(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}

struct EditStoryView: View {
    let story: LoveStory
    @ObservedObject var storiesData: LoveStoriesData
    let language: String
    @Environment(\.dismiss) var dismiss
    
    @State private var title: String
    @State private var content: String
    @State private var selectedLanguage: String
    
    init(story: LoveStory, storiesData: LoveStoriesData, language: String) {
        self.story = story
        self.storiesData = storiesData
        self.language = language
        _title = State(initialValue: story.title)
        _content = State(initialValue: story.content)
        _selectedLanguage = State(initialValue: story.language)
    }
    
    func localizedLanguageLabel(for language: String) -> String {
        switch language {
        case "ru": return "Язык"
        case "en": return "Language"
        case "fr": return "Langue"
        case "es": return "Idioma"
        case "pt": return "Idioma"
        case "zh": return "语言"
        default: return "Язык"
        }
    }
    
    func languageFlag(for language: String) -> String {
        switch language {
        case "ru": return "🇷🇺"
        case "en": return "🇬🇧"
        case "fr": return "🇫🇷"
        case "es": return "🇪🇸"
        case "pt": return "🇵🇹"
        case "zh": return "🇨🇳"
        default: return "🇷🇺"
        }
    }
    
    func languageName(for language: String) -> String {
        switch language {
        case "ru": return "Русский"
        case "en": return "English"
        case "fr": return "Français"
        case "es": return "Español"
        case "pt": return "Português"
        case "zh": return "中文"
        default: return "Русский"
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Language selector
                    VStack(alignment: .leading, spacing: 12) {
                        Text(localizedLanguageLabel(for: language))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        Menu {
                            Button(action: { selectedLanguage = "ru" }) {
                                HStack {
                                    Text("🇷🇺 Русский")
                                    if selectedLanguage == "ru" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            Button(action: { selectedLanguage = "en" }) {
                                HStack {
                                    Text("🇬🇧 English")
                                    if selectedLanguage == "en" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            Button(action: { selectedLanguage = "fr" }) {
                                HStack {
                                    Text("🇫🇷 Français")
                                    if selectedLanguage == "fr" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            Button(action: { selectedLanguage = "es" }) {
                                HStack {
                                    Text("🇪🇸 Español")
                                    if selectedLanguage == "es" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            Button(action: { selectedLanguage = "pt" }) {
                                HStack {
                                    Text("🇵🇹 Português")
                                    if selectedLanguage == "pt" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            Button(action: { selectedLanguage = "zh" }) {
                                HStack {
                                    Text("🇨🇳 中文")
                                    if selectedLanguage == "zh" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                        } label: {
                            HStack {
                                Text(languageFlag(for: selectedLanguage))
                                    .font(.title3)
                                Text(languageName(for: selectedLanguage))
                                    .foregroundColor(.white)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 12))
                                    .foregroundColor(.white.opacity(0.7))
                            }
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text(localizedTitleLabel(for: language))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        TextField(localizedTitlePlaceholder(for: language), text: $title)
                            .textFieldStyle(.plain)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text(localizedContentLabel(for: language))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                        TextEditor(text: $content)
                            .frame(minHeight: 200)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                            .foregroundColor(.white)
                            .scrollContentBackground(.hidden)
                    }
                    
                    Spacer()
                }
                .padding(20)
            }
            .navigationTitle(localizedNavTitle(for: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(localizedCancel(for: language)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedSave(for: language)) {
                        if !title.isEmpty && !content.isEmpty {
                            var updatedStory = story
                            updatedStory.title = title
                            updatedStory.content = content
                            updatedStory.language = selectedLanguage
                            storiesData.updateStory(updatedStory)
                            dismiss()
                        }
                    }
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .disabled(title.isEmpty || content.isEmpty)
                }
            }
        }
    }
    
    func localizedNavTitle(for language: String) -> String {
        switch language {
        case "ru": return "Редактировать"
        case "en": return "Edit"
        case "fr": return "Modifier"
        case "es": return "Editar"
        case "pt": return "Editar"
        case "zh": return "编辑"
        default: return "Редактировать"
        }
    }
    
    func localizedTitleLabel(for language: String) -> String {
        switch language {
        case "ru": return "Заголовок"
        case "en": return "Title"
        case "fr": return "Titre"
        case "es": return "Título"
        case "pt": return "Título"
        case "zh": return "标题"
        default: return "Заголовок"
        }
    }
    
    func localizedTitlePlaceholder(for language: String) -> String {
        switch language {
        case "ru": return "Введите заголовок..."
        case "en": return "Enter title..."
        case "fr": return "Entrez le titre..."
        case "es": return "Ingrese el título..."
        case "pt": return "Digite o título..."
        case "zh": return "输入标题..."
        default: return "Введите заголовок..."
        }
    }
    
    func localizedContentLabel(for language: String) -> String {
        switch language {
        case "ru": return "Содержание"
        case "en": return "Content"
        case "fr": return "Contenu"
        case "es": return "Contenido"
        case "pt": return "Conteúdo"
        case "zh": return "内容"
        default: return "Содержание"
        }
    }
    
    func localizedSave(for language: String) -> String {
        switch language {
        case "ru": return "Сохранить"
        case "en": return "Save"
        case "fr": return "Enregistrer"
        case "es": return "Guardar"
        case "pt": return "Salvar"
        case "zh": return "保存"
        default: return "Сохранить"
        }
    }
    
    func localizedCancel(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}

