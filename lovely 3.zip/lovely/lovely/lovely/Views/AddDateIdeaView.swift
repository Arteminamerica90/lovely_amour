//
//  AddDateIdeaView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct AddDateIdeaView: View {
    @ObservedObject var ideasData: DateIdeasData
    let language: String
    @Environment(\.dismiss) var dismiss
    
    @State private var title = ""
    @State private var description = ""
    @State private var selectedCategory: DateIdeaCategory = .classic
    @State private var authorName = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Author name
                        VStack(alignment: .leading, spacing: 12) {
                            Text(localizedAuthorLabel(for: language))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            TextField(localizedAuthorPlaceholder(for: language), text: $authorName)
                                .textFieldStyle(.plain)
                                .padding()
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                                .foregroundColor(.white)
                        }
                        
                        // Title
                        VStack(alignment: .leading, spacing: 12) {
                            Text(localizedTitleLabel(for: language))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            TextField(localizedTitlePlaceholder(for: language), text: $title)
                                .textFieldStyle(.plain)
                                .padding()
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                                .foregroundColor(.white)
                        }
                        
                        // Description
                        VStack(alignment: .leading, spacing: 12) {
                            Text(localizedDescriptionLabel(for: language))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            TextEditor(text: $description)
                                .frame(minHeight: 150)
                                .padding()
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                                .foregroundColor(.white)
                                .scrollContentBackground(.hidden)
                        }
                        
                        // Category
                        VStack(alignment: .leading, spacing: 12) {
                            Text(localizedCategoryLabel(for: language))
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(DateIdeaCategory.allCases) { category in
                                        Button(action: {
                                            selectedCategory = category
                                        }) {
                                            HStack(spacing: 8) {
                                                Image(systemName: category.icon)
                                                    .font(.system(size: 14))
                                                Text(category.localizedName(language: language))
                                                    .font(.system(size: 14, weight: .medium))
                                            }
                                            .foregroundColor(selectedCategory == category ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white)
                                            .padding(.horizontal, 16)
                                            .padding(.vertical, 10)
                                            .background {
                                                if selectedCategory == category {
                                                    RoundedRectangle(cornerRadius: 20)
                                                        .fill(Color.white)
                                                } else {
                                                    RoundedRectangle(cornerRadius: 20)
                                                        .fill(Color.clear)
                                                }
                                            }
                                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                                        }
                                    }
                                }
                            }
                        }
                        
                        Spacer()
                    }
                    .padding(20)
                }
            }
            .navigationTitle(localizedNavTitle(for: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(localizedCancel(for: language)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedSave(for: language)) {
                        if !title.isEmpty && !description.isEmpty {
                            let idea = DateIdea(
                                title: title,
                                description: description,
                                category: selectedCategory,
                                isUserCreated: true,
                                authorName: authorName.isEmpty ? nil : authorName
                            )
                            ideasData.addIdea(idea)
                            dismiss()
                        }
                    }
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .disabled(title.isEmpty || description.isEmpty)
                }
            }
        }
    }
    
    func localizedNavTitle(for language: String) -> String {
        switch language {
        case "ru": return "Новая Идея"
        case "en": return "New Idea"
        case "fr": return "Nouvelle Idée"
        case "es": return "Nueva Idea"
        case "pt": return "Nova Ideia"
        case "zh": return "新想法"
        default: return "Новая Идея"
        }
    }
    
    func localizedAuthorLabel(for language: String) -> String {
        switch language {
        case "ru": return "Ваше имя (необязательно)"
        case "en": return "Your name (optional)"
        case "fr": return "Votre nom (optionnel)"
        case "es": return "Tu nombre (opcional)"
        case "pt": return "Seu nome (opcional)"
        case "zh": return "您的姓名（可选）"
        default: return "Ваше имя (необязательно)"
        }
    }
    
    func localizedAuthorPlaceholder(for language: String) -> String {
        switch language {
        case "ru": return "Введите ваше имя..."
        case "en": return "Enter your name..."
        case "fr": return "Entrez votre nom..."
        case "es": return "Ingresa tu nombre..."
        case "pt": return "Digite seu nome..."
        case "zh": return "输入您的姓名..."
        default: return "Введите ваше имя..."
        }
    }
    
    func localizedTitleLabel(for language: String) -> String {
        switch language {
        case "ru": return "Заголовок"
        case "en": return "Title"
        case "fr": return "Titre"
        case "es": return "Título"
        case "pt": return "Título"
        case "zh": return "标题"
        default: return "Заголовок"
        }
    }
    
    func localizedTitlePlaceholder(for language: String) -> String {
        switch language {
        case "ru": return "Введите заголовок идеи..."
        case "en": return "Enter idea title..."
        case "fr": return "Entrez le titre de l'idée..."
        case "es": return "Ingresa el título de la idea..."
        case "pt": return "Digite o título da ideia..."
        case "zh": return "输入想法标题..."
        default: return "Введите заголовок идеи..."
        }
    }
    
    func localizedDescriptionLabel(for language: String) -> String {
        switch language {
        case "ru": return "Описание"
        case "en": return "Description"
        case "fr": return "Description"
        case "es": return "Descripción"
        case "pt": return "Descrição"
        case "zh": return "描述"
        default: return "Описание"
        }
    }
    
    func localizedCategoryLabel(for language: String) -> String {
        switch language {
        case "ru": return "Категория"
        case "en": return "Category"
        case "fr": return "Catégorie"
        case "es": return "Categoría"
        case "pt": return "Categoria"
        case "zh": return "类别"
        default: return "Категория"
        }
    }
    
    func localizedSave(for language: String) -> String {
        switch language {
        case "ru": return "Сохранить"
        case "en": return "Save"
        case "fr": return "Enregistrer"
        case "es": return "Guardar"
        case "pt": return "Salvar"
        case "zh": return "保存"
        default: return "Сохранить"
        }
    }
    
    func localizedCancel(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}


