//
//  PaywallView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct PaywallView: View {
    @Environment(\.dismiss) var dismiss
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.2, green: 0.8, blue: 0.7),
                    Color(red: 0.3, green: 0.9, blue: 0.6)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer()
                
                Image(systemName: "heart.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.white)
                    .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                
                VStack(spacing: 16) {
                    Text(localizedTitle(for: selectedLanguage))
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    
                    Text(localizedMessage(for: selectedLanguage))
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    
                    Text(localizedPrice(for: selectedLanguage))
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.top, 8)
                }
                .padding(40)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
                .shadow(color: .black.opacity(0.2), radius: 20, x: 0, y: 10)
                
                VStack(spacing: 16) {
                    Button(action: {
                        // Handle purchase
                        dismiss()
                    }) {
                        Text(localizedPurchaseButton(for: selectedLanguage))
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(Color(red: 0.2, green: 0.8, blue: 0.7))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color.white, in: RoundedRectangle(cornerRadius: 16))
                    }
                    
                    Button(action: {
                        dismiss()
                    }) {
                        Text(localizedCancelButton(for: selectedLanguage))
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white.opacity(0.8))
                    }
                }
                .padding(.horizontal, 40)
                
                Spacer()
            }
            .padding(20)
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Особое Признание"
        case "en": return "Special Declaration"
        case "fr": return "Déclaration Spéciale"
        case "es": return "Declaración Especial"
        case "pt": return "Declaração Especial"
        case "zh": return "特别声明"
        default: return "Особое Признание"
        }
    }
    
    func localizedMessage(for language: String) -> String {
        switch language {
        case "ru": return "Мы можем создать для вас особое признание в любви"
        case "en": return "We can make you a special declaration of love"
        case "fr": return "Nous pouvons créer pour vous une déclaration d'amour spéciale"
        case "es": return "Podemos hacerte una declaración de amor especial"
        case "pt": return "Podemos fazer uma declaração de amor especial para você"
        case "zh": return "我们可以为您制作一份特别的爱情宣言"
        default: return "Мы можем создать для вас особое признание в любви"
        }
    }
    
    func localizedPrice(for language: String) -> String {
        switch language {
        case "ru": return "$500"
        case "en": return "$500"
        case "fr": return "500 $"
        case "es": return "$500"
        case "pt": return "$500"
        case "zh": return "$500"
        default: return "$500"
        }
    }
    
    func localizedPurchaseButton(for language: String) -> String {
        switch language {
        case "ru": return "Купить"
        case "en": return "Purchase"
        case "fr": return "Acheter"
        case "es": return "Comprar"
        case "pt": return "Comprar"
        case "zh": return "购买"
        default: return "Купить"
        }
    }
    
    func localizedCancelButton(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}


