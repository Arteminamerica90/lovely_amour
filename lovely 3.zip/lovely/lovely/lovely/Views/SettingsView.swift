//
//  SettingsView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    @State private var showPrivacyPolicy = false
    @State private var showTermsOfUse = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        SettingsRow(
                            icon: "doc.text.fill",
                            title: localizedPrivacyPolicyTitle(for: selectedLanguage),
                            action: { showPrivacyPolicy = true }
                        )
                        
                        SettingsRow(
                            icon: "doc.text.fill",
                            title: localizedTermsOfUseTitle(for: selectedLanguage),
                            action: { showTermsOfUse = true }
                        )
                        
                        SettingsRow(
                            icon: "info.circle.fill",
                            title: localizedAboutAppTitle(for: selectedLanguage),
                            subtitle: localizedVersion(for: selectedLanguage)
                        )
                    }
                    .padding()
                }
            }
            .navigationTitle(localizedSettingsTitle(for: selectedLanguage))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedDone(for: selectedLanguage)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
            }
            .sheet(isPresented: $showPrivacyPolicy) {
                DocumentView(
                    title: localizedPrivacyPolicyTitle(for: selectedLanguage),
                    content: privacyPolicyContent(for: selectedLanguage),
                    language: selectedLanguage
                )
            }
            .sheet(isPresented: $showTermsOfUse) {
                DocumentView(
                    title: localizedTermsOfUseTitle(for: selectedLanguage),
                    content: termsOfUseContent(for: selectedLanguage),
                    language: selectedLanguage
                )
            }
        }
    }
    
    private func privacyPolicyContent(for language: String) -> String {
        switch language {
        case "ru":
            return """
            Политика конфиденциальности
            
            Дата последнего обновления: 06.11.2025
            
            1. Введение
            Приложение "Слова Любви" уважает вашу конфиденциальность и обязуется защищать ваши личные данные.
            
            2. Информация, которую мы собираем
            - Избранные фразы сохраняются локально на вашем устройстве
            - Настройки приложения хранятся локально
            - Мы НЕ собираем персональные данные
            - Мы НЕ собираем данные о местоположении
            - Мы НЕ используем аналитику или трекинг
            
            3. Хранение данных
            Все данные хранятся локально на вашем устройстве. Мы не передаем ваши данные третьим лицам.
            
            4. Премиум подписка
            Платежи обрабатываются через App Store. Мы не имеем доступа к вашей платежной информации.
            
            5. Контакты
            Если у вас есть вопросы, пожалуйста, свяжитесь с нами через GitHub.
            
            Полная версия доступна на GitHub.
            """
        case "en":
            return """
            Privacy Policy
            
            Last Updated: November 6, 2025
            
            1. Introduction
            The "Words of Love" app respects your privacy and is committed to protecting your personal data.
            
            2. Information We Collect
            - Favorite phrases are saved locally on your device
            - App settings are stored locally
            - We DO NOT collect personal data
            - We DO NOT collect location data
            - We DO NOT use analytics or tracking
            
            3. Data Storage
            All data is stored locally on your device. We do not transfer your data to third parties.
            
            4. Premium Subscription
            Payments are processed through the App Store. We do not have access to your payment information.
            
            5. Contact
            If you have any questions, please contact us via GitHub.
            
            Full version is available on GitHub.
            """
        case "fr":
            return """
            Politique de confidentialité
            
            Dernière mise à jour : 6 novembre 2025
            
            1. Introduction
            L'application "Mots d'Amour" respecte votre vie privée et s'engage à protéger vos données personnelles.
            
            2. Informations que nous collectons
            - Les phrases favorites sont enregistrées localement sur votre appareil
            - Les paramètres de l'application sont stockés localement
            - Nous NE collectons PAS de données personnelles
            - Nous NE collectons PAS de données de localisation
            - Nous N'utilisons PAS d'analytique ou de suivi
            
            3. Stockage des données
            Toutes les données sont stockées localement sur votre appareil. Nous ne transférons pas vos données à des tiers.
            
            4. Abonnement Premium
            Les paiements sont traités via l'App Store. Nous n'avons pas accès à vos informations de paiement.
            
            5. Contact
            Si vous avez des questions, veuillez nous contacter via GitHub.
            
            La version complète est disponible sur GitHub.
            """
        case "es":
            return """
            Política de privacidad
            
            Última actualización: 6 de noviembre de 2025
            
            1. Introducción
            La aplicación "Palabras de Amor" respeta su privacidad y se compromete a proteger sus datos personales.
            
            2. Información que recopilamos
            - Las frases favoritas se guardan localmente en su dispositivo
            - La configuración de la aplicación se almacena localmente
            - NO recopilamos datos personales
            - NO recopilamos datos de ubicación
            - NO utilizamos análisis o seguimiento
            
            3. Almacenamiento de datos
            Todos los datos se almacenan localmente en su dispositivo. No transferimos sus datos a terceros.
            
            4. Suscripción Premium
            Los pagos se procesan a través de App Store. No tenemos acceso a su información de pago.
            
            5. Contacto
            Si tiene alguna pregunta, por favor contáctenos a través de GitHub.
            
            La versión completa está disponible en GitHub.
            """
        case "pt":
            return """
            Política de Privacidade
            
            Última atualização: 6 de novembro de 2025
            
            1. Introdução
            O aplicativo "Palavras de Amor" respeita sua privacidade e se compromete a proteger seus dados pessoais.
            
            2. Informações que coletamos
            - Frases favoritas são salvas localmente no seu dispositivo
            - Configurações do aplicativo são armazenadas localmente
            - NÃO coletamos dados pessoais
            - NÃO coletamos dados de localização
            - NÃO usamos análise ou rastreamento
            
            3. Armazenamento de dados
            Todos os dados são armazenados localmente no seu dispositivo. Não transferimos seus dados para terceiros.
            
            4. Assinatura Premium
            Os pagamentos são processados através da App Store. Não temos acesso às suas informações de pagamento.
            
            5. Contato
            Se você tiver alguma dúvida, entre em contato conosco via GitHub.
            
            A versão completa está disponível no GitHub.
            """
        case "zh":
            return """
            隐私政策
            
            最后更新：2025年11月6日
            
            1. 介绍
            "爱的词语"应用尊重您的隐私，并致力于保护您的个人数据。
            
            2. 我们收集的信息
            - 收藏的短语保存在您的设备本地
            - 应用设置存储在本地
            - 我们不收集个人数据
            - 我们不收集位置数据
            - 我们不使用分析或跟踪
            
            3. 数据存储
            所有数据都存储在您的设备本地。我们不会将您的数据转移给第三方。
            
            4. 高级订阅
            付款通过App Store处理。我们无法访问您的付款信息。
            
            5. 联系方式
            如果您有任何问题，请通过GitHub联系我们。
            
            完整版本可在GitHub上获得。
            """
        default:
            return privacyPolicyContent(for: "en")
        }
    }
    
    private func termsOfUseContent(for language: String) -> String {
        switch language {
        case "ru":
            return """
            Условия использования
            
            Дата последнего обновления: 06.11.2025
            
            1. Принятие условий
            Используя это Приложение, вы соглашаетесь соблюдать данные условия.
            
            2. Описание сервиса
            Приложение предоставляет коллекцию фраз для выражения любви.
            
            3. Использование приложения
            Бесплатная версия предоставляет доступ к фразам с ограничениями.
            Премиум версия предоставляет неограниченный доступ.
            
            4. Подписки и платежи
            Премиум подписка доступна через встроенные покупки App Store.
            Вы можете отменить подписку в любое время через настройки App Store.
            
            5. Интеллектуальная собственность
            Контент защищен авторским правом. Коммерческое использование запрещено.
            
            6. Открытый исходный код
            Исходный код доступен на GitHub.
            
            7. Ограничения использования
            Вы не можете использовать приложение для незаконных целей.
            
            8. Отказ от гарантий
            Приложение предоставляется "как есть" без гарантий.
            
            9. Контакты
            Если у вас есть вопросы, пожалуйста, свяжитесь с нами через GitHub.
            
            Полная версия доступна на GitHub.
            """
        case "en":
            return """
            Terms of Use
            
            Last Updated: November 6, 2025
            
            1. Acceptance of Terms
            By using this App, you agree to comply with these terms.
            
            2. Service Description
            The app provides a collection of phrases for expressing love.
            
            3. App Usage
            The free version provides limited access to phrases.
            The premium version provides unlimited access.
            
            4. Subscriptions and Payments
            Premium subscription is available through App Store in-app purchases.
            You can cancel your subscription at any time through App Store settings.
            
            5. Intellectual Property
            Content is protected by copyright. Commercial use is prohibited.
            
            6. Open Source Code
            Source code is available on GitHub.
            
            7. Usage Restrictions
            You may not use the app for illegal purposes.
            
            8. Disclaimer of Warranties
            The app is provided "as is" without warranties.
            
            9. Contact
            If you have any questions, please contact us via GitHub.
            
            Full version is available on GitHub.
            """
        case "fr":
            return """
            Conditions d'utilisation
            
            Dernière mise à jour : 6 novembre 2025
            
            1. Acceptation des conditions
            En utilisant cette application, vous acceptez de respecter ces conditions.
            
            2. Description du service
            L'application fournit une collection de phrases pour exprimer l'amour.
            
            3. Utilisation de l'application
            La version gratuite offre un accès limité aux phrases.
            La version premium offre un accès illimité.
            
            4. Abonnements et paiements
            L'abonnement premium est disponible via les achats intégrés de l'App Store.
            Vous pouvez annuler votre abonnement à tout moment via les paramètres de l'App Store.
            
            5. Propriété intellectuelle
            Le contenu est protégé par le droit d'auteur. L'utilisation commerciale est interdite.
            
            6. Code source ouvert
            Le code source est disponible sur GitHub.
            
            7. Restrictions d'utilisation
            Vous ne pouvez pas utiliser l'application à des fins illégales.
            
            8. Avertissement concernant les garanties
            L'application est fournie "en l'état" sans garanties.
            
            9. Contact
            Si vous avez des questions, veuillez nous contacter via GitHub.
            
            La version complète est disponible sur GitHub.
            """
        case "es":
            return """
            Términos de uso
            
            Última actualización: 6 de noviembre de 2025
            
            1. Aceptación de los términos
            Al usar esta aplicación, acepta cumplir con estos términos.
            
            2. Descripción del servicio
            La aplicación proporciona una colección de frases para expresar amor.
            
            3. Uso de la aplicación
            La versión gratuita proporciona acceso limitado a las frases.
            La versión premium proporciona acceso ilimitado.
            
            4. Suscripciones y pagos
            La suscripción premium está disponible a través de compras dentro de la aplicación de App Store.
            Puede cancelar su suscripción en cualquier momento a través de la configuración de App Store.
            
            5. Propiedad intelectual
            El contenido está protegido por derechos de autor. El uso comercial está prohibido.
            
            6. Código fuente abierto
            El código fuente está disponible en GitHub.
            
            7. Restricciones de uso
            No puede usar la aplicación para fines ilegales.
            
            8. Renuncia de garantías
            La aplicación se proporciona "tal cual" sin garantías.
            
            9. Contacto
            Si tiene alguna pregunta, por favor contáctenos a través de GitHub.
            
            La versión completa está disponible en GitHub.
            """
        case "pt":
            return """
            Termos de Uso
            
            Última atualização: 6 de novembro de 2025
            
            1. Aceitação dos termos
            Ao usar este aplicativo, você concorda em cumprir estes termos.
            
            2. Descrição do serviço
            O aplicativo fornece uma coleção de frases para expressar amor.
            
            3. Uso do aplicativo
            A versão gratuita fornece acesso limitado às frases.
            A versão premium fornece acesso ilimitado.
            
            4. Assinaturas e pagamentos
            A assinatura premium está disponível através de compras no aplicativo da App Store.
            Você pode cancelar sua assinatura a qualquer momento através das configurações da App Store.
            
            5. Propriedade intelectual
            O conteúdo é protegido por direitos autorais. O uso comercial é proibido.
            
            6. Código-fonte aberto
            O código-fonte está disponível no GitHub.
            
            7. Restrições de uso
            Você não pode usar o aplicativo para fins ilegais.
            
            8. Renúncia de garantias
            O aplicativo é fornecido "como está" sem garantias.
            
            9. Contato
            Se você tiver alguma dúvida, entre em contato conosco via GitHub.
            
            A versão completa está disponível no GitHub.
            """
        case "zh":
            return """
            使用条款
            
            最后更新：2025年11月6日
            
            1. 接受条款
            使用此应用程序即表示您同意遵守这些条款。
            
            2. 服务描述
            该应用程序提供用于表达爱情的短语集合。
            
            3. 应用程序使用
            免费版本提供对短语的有限访问。
            高级版本提供无限访问。
            
            4. 订阅和付款
            高级订阅可通过App Store应用内购买获得。
            您可以随时通过App Store设置取消订阅。
            
            5. 知识产权
            内容受版权保护。禁止商业使用。
            
            6. 开源代码
            源代码可在GitHub上获得。
            
            7. 使用限制
            您不得将应用程序用于非法目的。
            
            8. 免责声明
            应用程序按"原样"提供，不提供任何保证。
            
            9. 联系方式
            如果您有任何问题，请通过GitHub联系我们。
            
            完整版本可在GitHub上获得。
            """
        default:
            return termsOfUseContent(for: "en")
        }
    }
    
    func localizedSettingsTitle(for language: String) -> String {
        switch language {
        case "ru": return "Настройки"
        case "en": return "Settings"
        case "fr": return "Paramètres"
        case "es": return "Configuración"
        case "pt": return "Configurações"
        case "zh": return "设置"
        default: return "Settings"
        }
    }
    
    func localizedDone(for language: String) -> String {
        switch language {
        case "ru": return "Готово"
        case "en": return "Done"
        case "fr": return "Terminé"
        case "es": return "Hecho"
        case "pt": return "Concluído"
        case "zh": return "完成"
        default: return "Done"
        }
    }
    
    func localizedPrivacyPolicyTitle(for language: String) -> String {
        switch language {
        case "ru": return "Политика конфиденциальности"
        case "en": return "Privacy Policy"
        case "fr": return "Politique de confidentialité"
        case "es": return "Política de privacidad"
        case "pt": return "Política de Privacidade"
        case "zh": return "隐私政策"
        default: return "Privacy Policy"
        }
    }
    
    func localizedTermsOfUseTitle(for language: String) -> String {
        switch language {
        case "ru": return "Условия использования"
        case "en": return "Terms of Use"
        case "fr": return "Conditions d'utilisation"
        case "es": return "Términos de uso"
        case "pt": return "Termos de Uso"
        case "zh": return "使用条款"
        default: return "Terms of Use"
        }
    }
    
    func localizedAboutAppTitle(for language: String) -> String {
        switch language {
        case "ru": return "О приложении"
        case "en": return "About App"
        case "fr": return "À propos de l'application"
        case "es": return "Acerca de la aplicación"
        case "pt": return "Sobre o aplicativo"
        case "zh": return "关于应用"
        default: return "About App"
        }
    }
    
    func localizedVersion(for language: String) -> String {
        switch language {
        case "ru": return "Версия 1.0.0"
        case "en": return "Version 1.0.0"
        case "fr": return "Version 1.0.0"
        case "es": return "Versión 1.0.0"
        case "pt": return "Versão 1.0.0"
        case "zh": return "版本 1.0.0"
        default: return "Version 1.0.0"
        }
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    var subtitle: String? = nil
    var action: (() -> Void)? = nil
    
    var body: some View {
        Button(action: {
            action?()
        }) {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(.white)
                    .frame(width: 30)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                    
                    if let subtitle = subtitle {
                        Text(subtitle)
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.7))
                    }
                }
                
                Spacer()
                
                if action != nil {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.7))
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(.ultraThinMaterial)
            )
        }
        .disabled(action == nil)
    }
}

struct DocumentView: View {
    let title: String
    let content: String
    let language: String
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                Text(content)
                    .font(.system(size: 14))
                    .padding()
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedDone(for: language)) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func localizedDone(for language: String) -> String {
        switch language {
        case "ru": return "Готово"
        case "en": return "Done"
        case "fr": return "Terminé"
        case "es": return "Hecho"
        case "pt": return "Concluído"
        case "zh": return "完成"
        default: return "Done"
        }
    }
}

#Preview {
    SettingsView()
}


