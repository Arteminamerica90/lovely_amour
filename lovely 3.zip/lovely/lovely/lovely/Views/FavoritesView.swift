//
//  FavoritesView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct FavoritesView: View {
    @StateObject private var phrasesData = LovePhrasesData()
    @StateObject private var storiesData = LoveStoriesData()
    @StateObject private var ideasData = DateIdeasData()
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    @AppStorage("viewedFavorites") private var viewedFavoritesData: Data = Data()
    @AppStorage("lastViewedSection") private var lastViewedSection: String = "phrases"
    
    @State private var selectedSection: FavoriteSection = .phrases
    @State private var viewedItems: Set<String> = []
    @State private var showPaywall = false // Закомментировано: временно отключено
    
    enum FavoriteSection: String, CaseIterable {
        case phrases = "phrases"
        case stories = "stories"
        case ideas = "ideas"
        
        func localizedName(for language: String) -> String {
            switch self {
            case .phrases:
                switch language {
                case "ru": return "Фразы"
                case "en": return "Phrases"
                case "fr": return "Phrases"
                case "es": return "Frases"
                case "pt": return "Frases"
                case "zh": return "短语"
                default: return "Фразы"
                }
            case .stories:
                switch language {
                case "ru": return "Истории"
                case "en": return "Stories"
                case "fr": return "Histoires"
                case "es": return "Historias"
                case "pt": return "Histórias"
                case "zh": return "故事"
                default: return "Истории"
                }
            case .ideas:
                switch language {
                case "ru": return "Идеи"
                case "en": return "Ideas"
                case "fr": return "Idées"
                case "es": return "Ideas"
                case "pt": return "Ideias"
                case "zh": return "想法"
                default: return "Идеи"
                }
            }
        }
    }
    
    var favoritePhrases: [LovePhrase] {
        phrasesData.phrases.filter { $0.isFavorite }
    }
    
    var favoriteStories: [LoveStory] {
        storiesData.getStories(for: selectedLanguage).filter { $0.isFavorite }
    }
    
    var favoriteIdeas: [DateIdea] {
        ideasData.ideas.filter { $0.isFavorite }
    }
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                colors: [
                    Color(red: 0.2, green: 0.8, blue: 0.7),
                    Color(red: 0.3, green: 0.9, blue: 0.6),
                    Color(red: 0.4, green: 0.85, blue: 0.65)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            // Decorative circles
            GeometryReader { geometry in
                Circle()
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 200, height: 200)
                    .position(x: geometry.size.width * 0.8, y: geometry.size.height * 0.1)
                
                Circle()
                    .fill(Color.white.opacity(0.08))
                    .frame(width: 150, height: 150)
                    .position(x: geometry.size.width * 0.1, y: geometry.size.height * 0.3)
                
                Ellipse()
                    .fill(Color.white.opacity(0.06))
                    .frame(width: 250, height: 100)
                    .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.9)
            }
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("💕")
                        .font(.system(size: 40))
                    Text(localizedTitle(for: selectedLanguage))
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 16)
                
                // Section tabs
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(FavoriteSection.allCases, id: \.self) { section in
                            Button(action: {
                                selectedSection = section
                                saveViewedItems()
                            }) {
                                HStack(spacing: 8) {
                                    Image(systemName: sectionIcon(for: section))
                                        .font(.system(size: 14))
                                    Text(section.localizedName(for: selectedLanguage))
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .foregroundColor(selectedSection == section ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 10)
                                .background {
                                    if selectedSection == section {
                                        RoundedRectangle(cornerRadius: 20)
                                            .fill(Color.white)
                                    } else {
                                        RoundedRectangle(cornerRadius: 20)
                                            .fill(Color.clear)
                                    }
                                }
                                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 16)
                
                // Content
                ScrollView {
                    LazyVStack(spacing: 16) {
                        switch selectedSection {
                        case .phrases:
                            if favoritePhrases.isEmpty {
                                emptyStateView(
                                    icon: "heart.text.square",
                                    message: localizedEmptyPhrases(for: selectedLanguage)
                                )
                            } else {
                                ForEach(favoritePhrases) { phrase in
                                    PhraseCard(phrasesData: phrasesData, phrase: phrase, language: selectedLanguage) {
                                        phrasesData.toggleFavorite(phrase)
                                        saveViewedItems()
                                    }
                                    .onAppear {
                                        markAsViewed(itemId: phrase.id.uuidString, type: "phrase")
                                    }
                                }
                            }
                            
                        case .stories:
                            if favoriteStories.isEmpty {
                                emptyStateView(
                                    icon: "book",
                                    message: localizedEmptyStories(for: selectedLanguage)
                                )
                            } else {
                                ForEach(favoriteStories) { story in
                                    FavoriteStoryCard(story: story, language: selectedLanguage) {
                                        storiesData.toggleFavorite(story)
                                        saveViewedItems()
                                    }
                                    .onAppear {
                                        markAsViewed(itemId: story.id.uuidString, type: "story")
                                    }
                                }
                            }
                            
                        case .ideas:
                            if favoriteIdeas.isEmpty {
                                emptyStateView(
                                    icon: "sparkles",
                                    message: localizedEmptyIdeas(for: selectedLanguage)
                                )
                            } else {
                                ForEach(favoriteIdeas) { idea in
                                    IdeaCard(ideasData: ideasData, idea: idea, language: selectedLanguage) {
                                        ideasData.toggleFavorite(idea)
                                        saveViewedItems()
                                    }
                                    .onAppear {
                                        markAsViewed(itemId: idea.id.uuidString, type: "idea")
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
        }
        .onAppear {
            loadViewedItems()
            // Восстанавливаем последнюю просмотренную секцию
            if let section = FavoriteSection(rawValue: lastViewedSection) {
                selectedSection = section
            }
        }
        .onChange(of: selectedSection, initial: false) { _, newSection in
            lastViewedSection = newSection.rawValue
        }
        // Закомментировано: временно отключено показ PaywallView
        // .sheet(isPresented: $showPaywall) {
        //     PaywallView()
        // }
    }
    
    func sectionIcon(for section: FavoriteSection) -> String {
        switch section {
        case .phrases: return "heart.text.square.fill"
        case .stories: return "book.fill"
        case .ideas: return "sparkles"
        }
    }
    
    func emptyStateView(icon: String, message: String) -> some View {
        VStack(spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 60))
                .foregroundColor(.white.opacity(0.5))
            
            Text(message)
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
    
    func markAsViewed(itemId: String, type: String) {
        let key = "\(type)_\(itemId)"
        viewedItems.insert(key)
        saveViewedItems()
    }
    
    func saveViewedItems() {
        if let encoded = try? JSONEncoder().encode(Array(viewedItems)) {
            viewedFavoritesData = encoded
        }
    }
    
    func loadViewedItems() {
        if let decoded = try? JSONDecoder().decode([String].self, from: viewedFavoritesData) {
            viewedItems = Set(decoded)
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Избранное"
        case "en": return "Favorites"
        case "fr": return "Favoris"
        case "es": return "Favoritos"
        case "pt": return "Favoritos"
        case "zh": return "收藏"
        default: return "Избранное"
        }
    }
    
    func localizedEmptyPhrases(for language: String) -> String {
        switch language {
        case "ru": return "У вас пока нет избранных фраз"
        case "en": return "You don't have any favorite phrases yet"
        case "fr": return "Vous n'avez pas encore de phrases favorites"
        case "es": return "Aún no tienes frases favoritas"
        case "pt": return "Você ainda não tem frases favoritas"
        case "zh": return "您还没有收藏的短语"
        default: return "У вас пока нет избранных фраз"
        }
    }
    
    func localizedEmptyStories(for language: String) -> String {
        switch language {
        case "ru": return "У вас пока нет избранных историй"
        case "en": return "You don't have any favorite stories yet"
        case "fr": return "Vous n'avez pas encore d'histoires favorites"
        case "es": return "Aún no tienes historias favoritas"
        case "pt": return "Você ainda não tem histórias favoritas"
        case "zh": return "您还没有收藏的故事"
        default: return "У вас пока нет избранных историй"
        }
    }
    
    func localizedEmptyIdeas(for language: String) -> String {
        switch language {
        case "ru": return "У вас пока нет избранных идей"
        case "en": return "You don't have any favorite ideas yet"
        case "fr": return "Vous n'avez pas encore d'idées favorites"
        case "es": return "Aún no tienes ideas favoritas"
        case "pt": return "Você ainda não tem ideias favoritas"
        case "zh": return "您还没有收藏的想法"
        default: return "У вас пока нет избранных идей"
        }
    }
}

struct FavoriteStoryCard: View {
    let story: LoveStory
    let language: String
    let onFavoriteTap: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 8) {
                    Text(story.title)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                    
                    Text(story.content)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.leading)
                        .lineLimit(3)
                    
                    Text(story.date, style: .date)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white.opacity(0.6))
                }
                
                Spacer()
                
                Button(action: onFavoriteTap) {
                    Image(systemName: story.isFavorite ? "heart.fill" : "heart")
                        .font(.title3)
                        .foregroundColor(story.isFavorite ? .red : .white.opacity(0.7))
                }
            }
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
}

