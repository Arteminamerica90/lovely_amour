//
//  DateIdeasView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct DateIdeasView: View {
    @StateObject private var ideasData = DateIdeasData()
    @State private var selectedCategory: DateIdeaCategory? = nil
    @AppStorage("selectedLanguage") private var selectedLanguage: String = "ru"
    @State private var randomIdea: DateIdea?
    @State private var showRandomIdea = false
    @State private var showFavoritesOnly = false
    @State private var showAddIdea = false
    @State private var showSharedIdeas = false
    
    var filteredIdeas: [DateIdea] {
        var ideas = ideasData.ideas
        
        if showSharedIdeas {
            ideas = ideas.filter { $0.isUserCreated }
        }
        
        if showFavoritesOnly {
            ideas = ideas.filter { $0.isFavorite }
        }
        
        if let category = selectedCategory {
            ideas = ideas.filter { $0.category == category }
        }
        
        return ideas
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.2, green: 0.8, blue: 0.7),
                    Color(red: 0.3, green: 0.9, blue: 0.6)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("💕")
                        .font(.system(size: 40))
                    Text(localizedTitle(for: selectedLanguage))
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Spacer()
                    HStack(spacing: 12) {
                        Button(action: {
                            showFavoritesOnly.toggle()
                        }) {
                            Image(systemName: showFavoritesOnly ? "heart.fill" : "heart")
                                .font(.title2)
                                .foregroundColor(showFavoritesOnly ? .red : .white)
                        }
                        
                        Button(action: {
                            showSharedIdeas.toggle()
                        }) {
                            Image(systemName: showSharedIdeas ? "person.2.fill" : "person.2")
                                .font(.title2)
                                .foregroundColor(showSharedIdeas ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white)
                        }
                        
                        Button(action: {
                            showAddIdea = true
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                        
                        Button(action: {
                            // Получаем случайную идею из отфильтрованного списка
                            let availableIdeas = filteredIdeas.isEmpty ? ideasData.ideas : filteredIdeas
                            if let idea = availableIdeas.randomElement() {
                                randomIdea = idea
                            }
                        }) {
                            Image(systemName: "dice.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 16)
                
                // Category tabs
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        DateIdeaCategoryTab(
                            category: nil,
                            selectedCategory: $selectedCategory,
                            icon: "star.fill",
                            title: localizedAll(for: selectedLanguage),
                            language: selectedLanguage
                        )
                        
                        ForEach(DateIdeaCategory.allCases) { category in
                            DateIdeaCategoryTab(
                                category: category,
                                selectedCategory: $selectedCategory,
                                icon: category.icon,
                                title: category.localizedName(language: selectedLanguage),
                                language: selectedLanguage
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 16)
                
                // Ideas list
                if filteredIdeas.isEmpty {
                    VStack(spacing: 20) {
                        Spacer()
                        Image(systemName: "sparkles")
                            .font(.system(size: 60))
                            .foregroundColor(.white.opacity(0.7))
                        Text(localizedEmptyMessage(for: selectedLanguage))
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white.opacity(0.8))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                        Spacer()
                    }
                } else {
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(filteredIdeas) { idea in
                                IdeaCard(ideasData: ideasData, idea: idea, language: selectedLanguage) {
                                    ideasData.toggleFavorite(idea)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                    }
                }
            }
        }
        .sheet(item: $randomIdea) { idea in
            RandomIdeaView(idea: idea, language: selectedLanguage)
        }
        .sheet(isPresented: $showAddIdea) {
            AddDateIdeaView(ideasData: ideasData, language: selectedLanguage)
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Идеи для Свиданий"
        case "en": return "Date Ideas"
        case "fr": return "Idées de Rendez-vous"
        case "es": return "Ideas para Citas"
        case "pt": return "Ideias para Encontros"
        case "zh": return "约会想法"
        default: return "Идеи для Свиданий"
        }
    }
    
    func localizedAll(for language: String) -> String {
        switch language {
        case "ru": return "Все"
        case "en": return "All"
        case "fr": return "Tous"
        case "es": return "Todos"
        case "pt": return "Todos"
        case "zh": return "全部"
        default: return "Все"
        }
    }
    
    func localizedEmptyMessage(for language: String) -> String {
        switch language {
        case "ru": return "Нажмите на кубик, чтобы получить случайную идею!"
        case "en": return "Tap the dice to get a random idea!"
        case "fr": return "Appuyez sur le dé pour obtenir une idée aléatoire!"
        case "es": return "¡Toca el dado para obtener una idea aleatoria!"
        case "pt": return "Toque no dado para obter uma ideia aleatória!"
        case "zh": return "点击骰子获取随机想法！"
        default: return "Нажмите на кубик, чтобы получить случайную идею!"
        }
    }
}

struct IdeaCard: View {
    @ObservedObject var ideasData: DateIdeasData
    let idea: DateIdea
    let language: String
    let onFavoriteTap: () -> Void
    @State private var showCommentSheet = false
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text(idea.getTitle(for: language))
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.leading)
                
                Text(idea.getDescription(for: language))
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.white.opacity(0.9))
                    .multilineTextAlignment(.leading)
                
                if let comment = idea.userComment, !comment.isEmpty {
                    Text(comment)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundColor(.white.opacity(0.8))
                        .italic()
                        .padding(.top, 4)
                }
                
                HStack {
                    Text(idea.category.localizedName(language: language))
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white.opacity(0.7))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(
                            Capsule()
                                .fill(Color.white.opacity(0.2))
                        )
                    
                    if idea.isUserCreated, let authorName = idea.authorName {
                        Text("👤 \(authorName)")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(.white.opacity(0.6))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(
                                Capsule()
                                    .fill(Color.white.opacity(0.15))
                            )
                    }
                    
                    Spacer()
                }
            }
            
            VStack(spacing: 12) {
                Button(action: {
                    showCommentSheet = true
                }) {
                    Image(systemName: idea.userComment != nil && !idea.userComment!.isEmpty ? "text.bubble.fill" : "text.bubble")
                        .font(.title3)
                        .foregroundColor(idea.userComment != nil && !idea.userComment!.isEmpty ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white.opacity(0.7))
                }
                
                Button(action: onFavoriteTap) {
                    Image(systemName: idea.isFavorite ? "heart.fill" : "heart")
                        .font(.title3)
                        .foregroundColor(idea.isFavorite ? .red : .white.opacity(0.7))
                }
            }
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
        .sheet(isPresented: $showCommentSheet) {
            CommentView(
                text: idea.userComment ?? "",
                onSave: { comment in
                    ideasData.updateComment(idea, comment: comment.isEmpty ? nil : comment)
                },
                language: language
            )
        }
    }
}

struct DateIdeaCategoryTab: View {
    let category: DateIdeaCategory?
    @Binding var selectedCategory: DateIdeaCategory?
    let icon: String
    let title: String
    let language: String
    
    var isSelected: Bool {
        selectedCategory == category
    }
    
    var body: some View {
        Button(action: {
            selectedCategory = category
        }) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 14))
                Text(title)
                    .font(.system(size: 14, weight: .medium))
            }
            .foregroundColor(isSelected ? Color(red: 0.2, green: 0.8, blue: 0.7) : .white)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background {
                if isSelected {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                } else {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.clear)
                }
            }
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
        }
    }
}

struct RandomIdeaView: View {
    let idea: DateIdea
    let language: String
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 60))
                        .foregroundColor(.white)
                    
                    VStack(spacing: 16) {
                        Text(idea.getTitle(for: language))
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                        
                        Text(idea.getDescription(for: language))
                            .font(.system(size: 18, weight: .regular))
                            .foregroundColor(.white.opacity(0.9))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                        
                        Text(idea.category.localizedName(language: language))
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white.opacity(0.7))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(
                                Capsule()
                                    .fill(Color.white.opacity(0.2))
                            )
                    }
                    .padding(30)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
                    
                    Spacer()
                }
                .padding(40)
            }
            .navigationTitle(localizedTitle(for: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedClose(for: language)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
            }
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Случайная Идея"
        case "en": return "Random Idea"
        case "fr": return "Idée Aléatoire"
        case "es": return "Idea Aleatoria"
        case "pt": return "Ideia Aleatória"
        case "zh": return "随机想法"
        default: return "Случайная Идея"
        }
    }
    
    func localizedClose(for language: String) -> String {
        switch language {
        case "ru": return "Закрыть"
        case "en": return "Close"
        case "fr": return "Fermer"
        case "es": return "Cerrar"
        case "pt": return "Fechar"
        case "zh": return "关闭"
        default: return "Закрыть"
        }
    }
}

