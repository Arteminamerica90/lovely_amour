//
//  CommentView.swift
//  lovely
//
//  Created by Artem Menshikov on 06.11.2025.
//

import SwiftUI

struct CommentView: View {
    @State private var comment: String
    let onSave: (String) -> Void
    let language: String
    @Environment(\.dismiss) var dismiss
    
    init(text: String, onSave: @escaping (String) -> Void, language: String) {
        _comment = State(initialValue: text)
        self.onSave = onSave
        self.language = language
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.2, green: 0.8, blue: 0.7),
                        Color(red: 0.3, green: 0.9, blue: 0.6)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 20) {
                    Text(localizedTitle(for: language))
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                    
                    TextEditor(text: $comment)
                        .frame(minHeight: 200)
                        .padding()
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        .foregroundColor(.white)
                        .scrollContentBackground(.hidden)
                    
                    Spacer()
                }
                .padding(20)
            }
            .navigationTitle(localizedNavTitle(for: language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(localizedCancel(for: language)) {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(localizedSave(for: language)) {
                        onSave(comment)
                        dismiss()
                    }
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                }
            }
        }
    }
    
    func localizedNavTitle(for language: String) -> String {
        switch language {
        case "ru": return "Комментарий"
        case "en": return "Comment"
        case "fr": return "Commentaire"
        case "es": return "Comentario"
        case "pt": return "Comentário"
        case "zh": return "评论"
        default: return "Комментарий"
        }
    }
    
    func localizedTitle(for language: String) -> String {
        switch language {
        case "ru": return "Добавьте свой комментарий"
        case "en": return "Add your comment"
        case "fr": return "Ajoutez votre commentaire"
        case "es": return "Agrega tu comentario"
        case "pt": return "Adicione seu comentário"
        case "zh": return "添加您的评论"
        default: return "Добавьте свой комментарий"
        }
    }
    
    func localizedSave(for language: String) -> String {
        switch language {
        case "ru": return "Сохранить"
        case "en": return "Save"
        case "fr": return "Enregistrer"
        case "es": return "Guardar"
        case "pt": return "Salvar"
        case "zh": return "保存"
        default: return "Сохранить"
        }
    }
    
    func localizedCancel(for language: String) -> String {
        switch language {
        case "ru": return "Отмена"
        case "en": return "Cancel"
        case "fr": return "Annuler"
        case "es": return "Cancelar"
        case "pt": return "Cancelar"
        case "zh": return "取消"
        default: return "Отмена"
        }
    }
}


