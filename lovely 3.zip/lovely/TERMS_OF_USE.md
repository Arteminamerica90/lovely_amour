# Terms of Use

**Last updated:** November 6, 2025

## 1. Acceptance of Terms

Welcome to the “Lovely Words” application (“App”). By using this App, you agree to comply with and be bound by these Terms of Use (“Terms”). If you do not agree with any part of these Terms, please do not use the App.

## 2. Description of Service

The “Lovely Words” App provides a collection of phrases and romantic expressions. The App is available for free, with the option to purchase a Premium subscription for additional features.

## 3. Use of the App

### 3.1 Free Version
The free version of the App includes:
- Access to a curated collection of love phrases
- Phrase search functionality
- Category filters
- A limited number of favorite slots

### 3.2 Premium Version
The Premium subscription includes:
- Unlimited favorites
- Full access to all categories
- Exclusive phrases
- Daily reminders

## 4. Subscriptions and Payments

### 4.1 Premium Subscription
- Premium subscriptions are offered via App Store in-app purchases
- Subscriptions renew automatically unless cancelled
- Payments are processed by the App Store under its own terms

### 4.2 Cancelling a Subscription
- You can cancel at any time via your App Store account settings
- Cancellation takes effect at the end of the current billing period
- Refunds are governed by App Store policies

## 5. Intellectual Property

### 5.1 App Content
- All phrases and texts in the App are original or used under license
- Content is protected by copyright

### 5.2 Use of Content
- You may use the phrases for personal, non-commercial purposes
- Commercial use of the content requires written permission
- You may not copy, distribute, or sell the App’s content

## 6. Open Source

This project is open source and available on GitHub:
- Source code is provided “as is”
- You may use the code in accordance with the project license
- We are not responsible for third-party use of the code

## 7. Acceptable Use

You agree **NOT** to:
- Use the App for any unlawful purpose
- Attempt to hack or bypass the App’s security
- Copy or redistribute the App without permission
- Use automated systems to access the App
- Remove or alter copyright notices

## 8. Disclaimer of Warranties

The App is provided “as is” without warranties of any kind:
- We do not guarantee error-free operation
- We do not guarantee uninterrupted availability
- We are not responsible for data loss

## 9. Limitation of Liability

To the maximum extent permitted by law:
- We are not liable for any direct, indirect, or incidental damages
- We are not liable for loss of data or information
- Our total liability is limited to the amount paid for the subscription

## 10. Changes to These Terms

We reserve the right to modify these Terms at any time:
- Significant changes will be communicated via an App update
- Continued use of the App after changes constitutes acceptance

## 11. Termination

We reserve the right to:
- Suspend or terminate access to the App at any time
- Remove or block accounts that violate these Terms
- Take action against unlawful use

## 12. Governing Law

These Terms are governed by the laws of [your jurisdiction], without regard to conflict-of-law principles.

## 13. Contact

If you have questions about these Terms, please contact us:
- **Email:** [your email]
- **GitHub:** [repository link]

## 14. Severability

If any provision of these Terms is found to be invalid or unenforceable, the remaining provisions will remain in full force and effect.

## 15. Entire Agreement

These Terms, together with the Privacy Policy, constitute the entire agreement between you and us regarding use of the App.

---

**Note:** By using this App, you confirm that you have read, understood, and agree to these Terms of Use.


